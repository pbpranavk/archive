//Type your code here


function file1_init(){
  frmHome.preShow = frmHome_preShow; 
  
}


function frmHome_preShow(){
  var data = kony.contact.find('*',true);
 // kony.print(JSON.stringify(data));
  var nameLogos = [];
  for(var d in data){
  nameLogos.push(splitName(d.firstname));  
  }
  kony.print("a "+ data);
  kony.print("pranav --> nameLogos is" + nameLogos);	
  frmHome.segContacts.setData(data);
  
}

function splitName(s){

	var res = s.split(" ");
	var fin = "";
	if(res.length>1){
		var i = 1;
		for(;i<res.length;i++){
			if(res[i].charAt(0) !== ''){
				fin = res[0].charAt(0)+""+res[i].charAt(0).toUpperCase();
				break;}}
			if(i === res.length)
				fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
			//alert(fin);
	}else{
		fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
		//alert(fin);
	}
  return fin;
}

/*
function randomSkinGene(max, min){  
    return Math.floor(Math.random() * (max - min + 1)) + min;  	
} */
