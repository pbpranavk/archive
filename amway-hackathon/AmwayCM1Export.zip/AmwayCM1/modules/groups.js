var isFromProspects = false;
var isFromCustomers = false;
var isFromRegCust = false;
var isFromAbo = false;
var gblisFromCustom = [false,false,false,false];
var gblCustomGroupNames = [];
function splitName(s){
	var res = [];
	res= s.split(" ");
	var fin = "";
	if(res.length>1){
		var i = 1;
		for(;i<res.length;i++){
			if(res[i].charAt(0) !== ''){
				fin = res[0].charAt(0)+""+res[i].charAt(0).toUpperCase();
				break;}}
			if(i === res.length)
				fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
			//alert(fin);
	}else{
		fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
		//alert(fin);
	}
  return fin;
}

/*
function randomSkinGene(max, min){  
  if(count===10){
    count=1;
    return 10;
  }
  else{
    var p =count;
    count++;
    return p;
  }
  //return Math.floor(Math.random() * (max - min + 1)) + min;  	
} 
*/

function frmGroups_init(){
  frmGroups.preShow = frmGroups_preShow;
  frmGroups.postShow = frmGroups_postShow;
  frmGroups.btnProspects.onClick = frmGroups_btnProspects_onClick;
  frmGroups.btnContacts.onClick =  frmGroups_btnContacts_onClick; 
  frmGroups.btnCust.onClick = frmGroups_btnCust_onClick;
  frmGroups.btnReg.onClick = frmGroups_btnReg_onClick;
  frmGroups.btnAbo.onClick = frmGroups_btnAbo_onClick;
  frmGroups.imgCreateCustom.onTouchMove = setVisible;
  frmGroups.btnSubmit.onClick= CustomGroups;
  frmGroups.btn1.onClick = customGroupOnclick;
  frmGroups.btn2.onClick = customGroupOnclick;
  frmGroups.btn3.onClick = customGroupOnclick;
  frmGroups.btn4.onClick = customGroupOnclick;
  for (var i = 1 ;i < 9 ;i++){
    frmGroups["btnMore" + i].onClick = dynNav;
  }
  frmGroups.onDeviceBack = frmGroups_onDeviceBack;
}

function dynNav(){
  frmDyn.show();
}

function frmGroups_preShow(){
//do nothing; 
  frmGroups.flxHighlight1.isVisible = false;
  frmGroups.flxScroller.top = "19.5%";
  resetGroupProps();
  populateCustomGroups();
}

function frmGroups_postShow(){
 kony.application.dismissLoadingScreen();
 initiateAnimation(); 
}

function frmGroups_btnProspects_onClick(){
  isFromProspects = true;
  // isFromEdit = false;
  showContactDetails(gblProsArr, "Prospects");
  kony.application.showLoadingScreen();
  frmGroupDetails.show();
  
}

function frmGroups_btnCust_onClick(){
  isFromCustomers = true;
  showContactDetails(gblCustArr, "Customers");
  kony.application.showLoadingScreen();
  frmGroupDetails.show();
}


function frmGroups_btnReg_onClick(){
  isFromRegCust = true;
  showContactDetails(gblRegCustArr, "Registered Customers");
  kony.application.showLoadingScreen();
  frmGroupDetails.show();
}

function frmGroups_btnAbo_onClick(){
  isFromAbo = true;
  showContactDetails(gblisAboArr, "ABO");
  kony.application.showLoadingScreen();
  frmGroupDetails.show();
}

//Savanth ---> setting left and right pf groups
function resetGroupProps(){
   frmGroups.flxPros.left = "-100%"
   frmGroups.flxCust.left = "100%"
   frmGroups.flxreg.left  = "-100%"
   frmGroups.flxABO.left  = "100%"
   frmGroups.flxcust1.left = "-100%"
   frmGroups.flxcust2.left = "100%"
   frmGroups.flxcust3.left = "-100%"
   frmGroups.flxcust4.left = "100%"
} 

//Savanth ----> Animating groups
function AnimateGroups(){
 //prop
  frmGroups.flxPros.animate(
    kony.ui.createAnimation({
        100: {
            left: "1%"
        }
    }), {
        duration: 0.8,
        delay: 0,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {}
    });
    //Customer
    frmGroups.flxCust.animate(
    kony.ui.createAnimation({
        100: {
            left: "1%"
        }
    }), {
        duration: 0.8,
        delay: 0,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {}
    });
   //Reg
   frmGroups.flxreg.animate(
    kony.ui.createAnimation({
        100: {
            left: "1%"
        }
    }), {
        duration: 0.8,
        delay: 0,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {}
    });
    //ABO
    frmGroups.flxABO.animate(
    kony.ui.createAnimation({
        100: {
            left: "1%"
        }
    }), {
        duration: 0.8,
        delay: 0,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {}
    });
}

function frmGroups_btnContacts_onClick(){
  frmDyn.show();
}

//Type your code h
var f1=0,f2=0,f3=0,f4=0;
var ar=["flxPros","flxCust","flxreg","flxABO","flxcust1","flxcust2","flxcust3","flxcust4"];
function addDynamicWidgets(){
  
  var name=frmGroups.txtName.text;
  //gblCustomGroupNames.push(name);
  var flxname="flx"+name;
  frmGroups.flxScroller.isVisible=true;
frmGroups.flxCreateGroup.isVisible=false;
    flxname = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": flxname,
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "1%",
        "skin": "flxSkn2",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxname.setDefaultUnit(kony.flex.DP);
    var btnCust = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "100%",
        "id": "btnCust",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": name,
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
   var btnProsMore = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnProsMore",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxname.add(btnCust, btnProsMore);
    frmGroups.flxInnerGrps.add(flxname);
   // gblcustomflex[i]
}

function setVisible(){
  frmGroups.flxScroller.isVisible=false;
frmGroups.flxCreateGroup.isVisible=true;
}

function setTextName(){
  var name=frmGroups.txtName.text;
}

function CustomGroups(){
   var name;
  frmGroups.flxScroller.isVisible=true;
frmGroups.flxCreateGroup.isVisible=false;
  if(f1===0){
    f1=1;
    name=frmGroups.txtName.text;
    frmGroups.btn1.text=name;
    frmGroups.flxcust1.isVisible=true;
  }
  else if(f2===0){
    f2=1;
    name=frmGroups.txtName.text;
    frmGroups.btn2.text=name;
    frmGroups.flxcust2.isVisible=true;
  }
  else if(f3===0){
    f3=1;
    name=frmGroups.txtName.text;
    frmGroups.btn3.text=name;
    frmGroups.flxcust3.isVisible=true;
  }
  else if(f4===0){
    f4=1;
    name=frmGroups.txtName.text;
    frmGroups.btn4.text=name;
    frmGroups.flxcust4.isVisible=true;
  }
  else{
    alert("Delete existing grp to create new one");
  }
  gblCustomGroupNames.push(name);
}

function initiateAnimation(){
  for(var i=0;i<ar.length;i++){
    frmGroups[ar[i]].animate(
    kony.ui.createAnimation({
        100: {
            left: "1%"
        }
    }), {
        duration: 0.8,
        delay: 0,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {}
    });
  }
}

function populateCustomGroups(){
  var j;
  for(var i=0 ; i<gblCustomGroupNames.length; i++){
    j=i+1;
    frmGroups["flxcust" + j].text = gblCustomGroupNames[i];
    frmGroups["flxcust" + j].setVisibility(true);
  }
}

function customGroupOnclick(source){
  var id = source.id.substring(source.id.length-1);
  kony.application.showLoadingScreen();
  kony.print("Savanth ---> id is " + id);
  showContactDetails(gblcust[id], gblCustomGroupNames[id-1] );
  gblisFromCustom[id] = true;
  frmGroupDetails.show();
}


function frmGroups_onDeviceBack(){
  frmDyn.flxAdd.removeAll();
  genContacts();
  frmDyn.show();
}