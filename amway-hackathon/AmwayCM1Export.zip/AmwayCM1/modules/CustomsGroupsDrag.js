//Type your code here
var gblcust = {};
gblcust["1"] =[];
gblcust["2"] =[];
gblcust["3"] =[];
gblcust["4"] =[];

var gblBucketFall = null;
function form_IntStart(){
  frmTemp.destroy();
  frmStart.preShow = Start_PreShow;
  frmStart.flxGroup1.onTouchEnd = bucketFall;
  frmStart.flxGroup2.onTouchEnd = bucketFall;
  frmStart.flxGroup3.onTouchEnd = bucketFall;
  frmStart.flxGroup4.onTouchEnd = bucketFall;
}

function Start_PreShow(){
  var Tempflex = gblTileClicked.clone();
  kony.print("Savanth ---> widget " + JSON.stringify(gblTileClicked));
  kony.print("Savanth ---> widget " + JSON.stringify(Tempflex));
  Tempflex["left"] = 130;
  Tempflex["top"] = 150;
  Tempflex["height"] = 125;
  Tempflex["width"] = 125;
  Tempflex["skin"] = gblSkinForAnim;
  Tempflex["zIndex"] = 10;
  frmStart.add(Tempflex);
  gblBucketFall = Tempflex;
  populateBuckets();
}

function bucketFall(source,x,y){
  var ParamX = (((parseInt(source.id.substring(source.id.length-1 , source.id.length))) - 1)*( Math.round(0.25*(formWidth + 70)))); //+ Math.round(0.125*(formWidth + 70))
  var ParamY =  Math.round(0.81*(formHeight +70));
  kony.print("Savanth ---> paramX = " + ParamX + " paramY = " + ParamY );
  var id = getId(gblBucketFall); 
  var j = source.id.substring(source.id.length -1) ;
  gblcust[j].push(data1[id]);
  showContactDetails( gblcust[j], gblCustomGroupNames[j-1] );
  frmStart["lblNum" + j].text = gblcust[j].length.toPrecision();
  gblisFromCustom[j] = true;
  scaleAnim(gblBucketFall,ParamX,ParamY);
}

function animateFromCentre(source,x,y){
     kony.print("Savanth ---> " + JSON.stringify(source));
     var transformRotate = kony.ui.makeAffineTransform();
     var transformScale = kony.ui.makeAffineTransform();
     var transformTranslate = kony.ui.makeAffineTransform();
     transformScale.scale( 0,0 );
     transformRotate.rotate(90);
     //transformTranslate
      source.animate(
     kony.ui.createAnimation({
        100: {
            top: y,
            left: x,
            transform: transformScale,
        }
    }), {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {
          //frmTemp.remove(source);
          //frmDyn.show();
        }
    });
}

function populateBuckets(){
 kony.print("Savanth ---> Inside Populating Buckets");
 var j;
 kony.print("Savanth ---> jsp" + gblCustomGroupNames.length );
 for(var i=0; i< gblCustomGroupNames.length; i++ ){
   j = i+1;
   kony.print("Savanth ---> CustomGroup " + gblCustomGroupNames[i]);
   frmStart["lblNum" + j].text = gblcust[j].length.toPrecision();
   frmStart["lblGrpName" + j].text = gblCustomGroupNames[i];
   frmStart["lblGrpName" + j].text = gblCustomGroupNames[i];
   frmStart["flxGroup" + j].setVisibility(true);
 }
}
