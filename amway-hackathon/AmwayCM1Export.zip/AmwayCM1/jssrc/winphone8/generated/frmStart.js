function addWidgetsfrmStart() {
    frmStart.setDefaultUnit(kony.flex.DP);
    var segCOntactDetails = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "CopybtnMore0i78c440eea5a48": "r",
            "btnCancel1": "r",
            "btnEdit1": "r",
            "btnMore2": "Button",
            "lblDummyData1": "ST",
            "lblDummyData2": "ST",
            "lblShortName1": "Sree teja",
            "lblShortName2": "Sree teja"
        }, {
            "CopybtnMore0i78c440eea5a48": "r",
            "btnCancel1": "r",
            "btnEdit1": "r",
            "btnMore2": "Button",
            "lblDummyData1": "ST",
            "lblDummyData2": "ST",
            "lblShortName1": "Sree teja",
            "lblShortName2": "Sree teja"
        }, {
            "CopybtnMore0i78c440eea5a48": "r",
            "btnCancel1": "r",
            "btnEdit1": "r",
            "btnMore2": "Button",
            "lblDummyData1": "ST",
            "lblDummyData2": "ST",
            "lblShortName1": "Sree teja",
            "lblShortName2": "Sree teja"
        }],
        "enableCache": false,
        "groupCells": false,
        "height": "93.77%",
        "id": "segCOntactDetails",
        "isVisible": true,
        "left": "-0.06%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "Copyseg0e7ddd07434c348",
        "rowSkin": "Copyseg0b4da6b7eed9b46",
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": false,
        "showScrollbars": false,
        "top": "6.52%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "CopybtnMore0i78c440eea5a48": "CopybtnMore0i78c440eea5a48",
            "btnCancel1": "btnCancel1",
            "btnEdit1": "btnEdit1",
            "btnMore2": "btnMore2",
            "flxContactDetails1": "flxContactDetails1",
            "flxContactDetails2": "flxContactDetails2",
            "flxParent": "flxParent",
            "lblDummyData1": "lblDummyData1",
            "lblDummyData2": "lblDummyData2",
            "lblShortName1": "lblShortName1",
            "lblShortName2": "lblShortName2"
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmStart.add(segCOntactDetails);
};

function frmStartGlobals() {
    frmStart = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmStart,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "id": "frmStart",
        "init": AS_Form_a8f2eee4342b43aa86bb123b3d480ec9,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0eb1ea9f876fe4a"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "directChildrenIDs": ["segCOntactDetails"],
        "retainScrollPosition": false,
        "titleBar": true
    });
};