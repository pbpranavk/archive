function addWidgetsfrmHome() {
    frmHome.setDefaultUnit(kony.flex.DP);
    frmHome.add();
};

function frmHomeGlobals() {
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "init": AS_Form_af7df5d139ef4554bdfbdac5ddb5d908,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0ea6046e1c67648"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "retainScrollPosition": false,
        "titleBar": true
    });
};