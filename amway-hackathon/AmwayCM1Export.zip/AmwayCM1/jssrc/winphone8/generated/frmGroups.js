function addWidgetsfrmGroups() {
    frmGroups.setDefaultUnit(kony.flex.DP);
    var logo = new com.org.amwayLogo.logo({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "11.92%",
        "id": "logo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "masterType": constants.MASTER_TYPE_DEFAULT,
        "skin": "CopyslFbox0ef67a12bf4cc4a",
        "top": "0dp"
    }, {}, {});
    logo.flxHeader.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.flxHeader.height = "100.00%";
    logo.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.height = "11.92%";
    logo.left = "0dp";
    logo.top = "0dp";
    var flx = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "9.67%",
        "id": "flx",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0.00%",
        "top": "12%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flx.setDefaultUnit(kony.flex.DP);
    var FlexScrollContainer0iaaf625f038149 = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableCache": false,
        "enableScrolling": true,
        "height": "220dp",
        "horizontalScrollIndicator": true,
        "id": "FlexScrollContainer0iaaf625f038149",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "26dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "194dp",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexScrollContainer0iaaf625f038149.setDefaultUnit(kony.flex.DP);
    FlexScrollContainer0iaaf625f038149.add();
    var Button0db5c8980cadb44 = new kony.ui.Button({
        "enableCache": false,
        "focusSkin": "CopyslButtonGlossRed0b8bee671c66541",
        "height": "99%",
        "id": "Button0db5c8980cadb44",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0i2c3f5a757704b",
        "text": "Contacts",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h7544ba940654d = new kony.ui.Label({
        "enableCache": false,
        "height": "100%",
        "id": "Label0h7544ba940654d",
        "isVisible": true,
        "left": "49%",
        "skin": "CopyslLabel0e0e014afb8bd44",
        "text": "Label",
        "top": "0%",
        "width": "3dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyButton0j697f3c759984e = new kony.ui.Button({
        "enableCache": false,
        "height": "99%",
        "id": "CopyButton0j697f3c759984e",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslButtonGlossBlue0bf7532741aa845",
        "text": "Groups",
        "top": "0.00%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flx.add(FlexScrollContainer0iaaf625f038149, Button0db5c8980cadb44, Label0h7544ba940654d, CopyButton0j697f3c759984e);
    var flxHighlight1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "3dp",
        "id": "flxHighlight1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "21.57%",
        "width": "49%",
        "zIndex": 1
    }, {}, {});
    flxHighlight1.setDefaultUnit(kony.flex.DP);
    flxHighlight1.add();
    var flxHighlight2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "3dp",
        "id": "flxHighlight2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "49.90%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "21.57%",
        "width": "50.10%",
        "zIndex": 1
    }, {}, {});
    flxHighlight2.setDefaultUnit(kony.flex.DP);
    flxHighlight2.add();
    var flxScroller = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableCache": false,
        "enableScrolling": true,
        "height": "397dp",
        "horizontalScrollIndicator": true,
        "id": "flxScroller",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "134dp",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxScroller.setDefaultUnit(kony.flex.DP);
    var flxInnerGrps = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "85%",
        "id": "flxInnerGrps",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxInnerGrps.setDefaultUnit(kony.flex.DP);
    var flxPros = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "15%",
        "id": "flxPros",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "CopyslFbox0d47520a8a9d24c",
        "top": "8.00%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxPros.setDefaultUnit(kony.flex.DP);
    var btnProspects = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnProspects",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0cf1c08611f544e",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnProsMore = new kony.ui.Button({
        "enableCache": false,
        "height": "100.00%",
        "id": "btnProsMore",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPros.add(btnProspects, btnProsMore);
    var flxCust = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "15%",
        "id": "flxCust",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "CopyslFbox0icc54711f63e4c",
        "top": "2.00%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCust.setDefaultUnit(kony.flex.DP);
    var btnCust = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnCust",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0cf1c08611f544e",
        "text": "Customers",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnCustMore = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnCustMore",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0dfbe554d8af446",
        "top": "2dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCust.add(btnCust, btnCustMore);
    var flxreg = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "15%",
        "id": "flxreg",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "CopyslFbox0jefe809fe20d47",
        "top": "2.00%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxreg.setDefaultUnit(kony.flex.DP);
    var btnReg = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnReg",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0cf1c08611f544e",
        "text": "Registered Customers",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnRegMore = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnRegMore",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0dd42b1a9ba684e",
        "top": "2dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxreg.add(btnReg, btnRegMore);
    var flxABO = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "15%",
        "id": "flxABO",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "CopyslFbox0gf1f0f4f93ed43",
        "top": "2.00%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxABO.setDefaultUnit(kony.flex.DP);
    var btnAbo = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnAbo",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0cf1c08611f544e",
        "text": "Might be an ABO",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnAboMore = new kony.ui.Button({
        "enableCache": false,
        "height": "100%",
        "id": "btnAboMore",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0e5aac76c081943",
        "top": "2dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxABO.add(btnAbo, btnAboMore);
    flxInnerGrps.add(flxPros, flxCust, flxreg, flxABO);
    flxScroller.add(flxInnerGrps);
    var Image0h3b6a3e7ff0046 = new kony.ui.Image2({
        "enableCache": false,
        "height": "57dp",
        "id": "Image0h3b6a3e7ff0046",
        "isVisible": true,
        "left": "78.67%",
        "src": "group.png",
        "top": "88.04%",
        "width": "63dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmGroups.add(logo, flx, flxHighlight1, flxHighlight2, flxScroller, Image0h3b6a3e7ff0046);
};

function frmGroupsGlobals() {
    frmGroups = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmGroups,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "id": "frmGroups",
        "init": AS_Form_b68bd7768f874a96b4c5937cb01763b5,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "postShow": AS_Form_i84459361419498e81f25186a0d12993,
        "skin": "CopyslForm0bf4f198a6d174a"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "directChildrenIDs": ["btnAbo", "btnAboMore", "btnCust", "btnCustMore", "btnProsMore", "btnProspects", "btnReg", "btnRegMore", "Button0db5c8980cadb44", "CopyButton0j697f3c759984e", "FlexScrollContainer0iaaf625f038149", "flx", "flxABO", "flxCust", "flxHighlight1", "flxHighlight2", "flxInnerGrps", "flxPros", "flxreg", "flxScroller", "Image0h3b6a3e7ff0046", "Label0h7544ba940654d", "logo"],
        "retainScrollPosition": false,
        "titleBar": true
    });
};