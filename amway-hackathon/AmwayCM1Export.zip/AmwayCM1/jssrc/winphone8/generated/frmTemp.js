function addWidgetsfrmTemp() {
    frmTemp.setDefaultUnit(kony.flex.DP);
    var flxBuckets = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "100%",
        "id": "flxBuckets",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0d710c892040646",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxBuckets.setDefaultUnit(kony.flex.DP);
    var flxBucketProspect = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "0%",
        "clipBounds": true,
        "enableCache": false,
        "height": "280dp",
        "id": "flxBucketProspect",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    flxBucketProspect.setDefaultUnit(kony.flex.DP);
    var ImgProspect = new kony.ui.Image2({
        "centerY": "64%",
        "enableCache": false,
        "height": "73dp",
        "id": "ImgProspect",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h9f6137078bb41 = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0h9f6137078bb41",
        "isVisible": true,
        "left": "151dp",
        "skin": "sknLblBottomText",
        "text": "Prospect",
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0f43418a854134b = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0f43418a854134b",
        "isVisible": true,
        "left": "169dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBucketProspect.add(ImgProspect, Label0h9f6137078bb41, Label0f43418a854134b);
    var CopyflxBucketProspect0f5102205494548 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "1%",
        "clipBounds": true,
        "enableCache": false,
        "height": "280dp",
        "id": "CopyflxBucketProspect0f5102205494548",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f5102205494548.setDefaultUnit(kony.flex.DP);
    var imgCustomer = new kony.ui.Image2({
        "centerY": "62%",
        "enableCache": false,
        "height": "73dp",
        "id": "imgCustomer",
        "isVisible": true,
        "left": "24%",
        "right": "30%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0b7eb7a6af8b444 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0b7eb7a6af8b444",
        "isVisible": true,
        "left": "52dp",
        "skin": "sknLblBottomText",
        "text": "Customer",
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0e911c1264c4e4c = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0e911c1264c4e4c",
        "isVisible": true,
        "left": "88dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "top": "170dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0f5102205494548.add(imgCustomer, CopyLabel0b7eb7a6af8b444, CopyLabel0e911c1264c4e4c);
    var CopyflxBucketProspect0f2f6d40304a94f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "100%",
        "clipBounds": true,
        "enableCache": false,
        "height": "290dp",
        "id": "CopyflxBucketProspect0f2f6d40304a94f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f2f6d40304a94f.setDefaultUnit(kony.flex.DP);
    var imgRegisteredCustomer = new kony.ui.Image2({
        "centerY": "32%",
        "enableCache": false,
        "height": "73dp",
        "id": "imgRegisteredCustomer",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0j97fad3d02f648 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0j97fad3d02f648",
        "isVisible": true,
        "left": "145dp",
        "skin": "sknLblBottomText",
        "text": "Reg Customer",
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0dc9ac6e327e049 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0dc9ac6e327e049",
        "isVisible": true,
        "left": "172dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "top": "89dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0f2f6d40304a94f.add(imgRegisteredCustomer, CopyLabel0j97fad3d02f648, CopyLabel0dc9ac6e327e049);
    var CopyflxBucketProspect0bc4c4a78143f42 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "100%",
        "clipBounds": true,
        "enableCache": false,
        "height": "290dp",
        "id": "CopyflxBucketProspect0bc4c4a78143f42",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0bc4c4a78143f42.setDefaultUnit(kony.flex.DP);
    var imgABO = new kony.ui.Image2({
        "enableCache": false,
        "height": "73dp",
        "id": "imgABO",
        "isVisible": true,
        "left": "25%",
        "right": "10%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "19%",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0fcf13fc0192541 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0fcf13fc0192541",
        "isVisible": true,
        "left": "83dp",
        "skin": "sknLblBottomText",
        "text": "ABO",
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0h5a7ed6ab01341 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0h5a7ed6ab01341",
        "isVisible": true,
        "left": "93dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "top": "90dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0bc4c4a78143f42.add(imgABO, CopyLabel0fcf13fc0192541, CopyLabel0h5a7ed6ab01341);
    var flexAnim = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "147dp",
        "id": "flexAnim",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "93dp",
        "skin": "flxSkn10",
        "top": "193dp",
        "width": "50%",
        "zIndex": 200
    }, {}, {});
    flexAnim.setDefaultUnit(kony.flex.DP);
    flexAnim.add();
    flxBuckets.add(flxBucketProspect, CopyflxBucketProspect0f5102205494548, CopyflxBucketProspect0f2f6d40304a94f, CopyflxBucketProspect0bc4c4a78143f42, flexAnim);
    frmTemp.add(flxBuckets);
};

function frmTempGlobals() {
    frmTemp = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmTemp,
        "bounces": false,
        "enableScrolling": false,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "id": "frmTemp",
        "init": AS_Form_he9cc1789e194c3b82f90fefb54717a2,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "pagingEnabled": false,
        "skin": "CopyslForm0ae77c57420de40"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "directChildrenIDs": ["CopyflxBucketProspect0bc4c4a78143f42", "CopyflxBucketProspect0f2f6d40304a94f", "CopyflxBucketProspect0f5102205494548", "CopyLabel0b7eb7a6af8b444", "CopyLabel0dc9ac6e327e049", "CopyLabel0e911c1264c4e4c", "CopyLabel0fcf13fc0192541", "CopyLabel0h5a7ed6ab01341", "CopyLabel0j97fad3d02f648", "flexAnim", "flxBucketProspect", "flxBuckets", "imgABO", "imgCustomer", "ImgProspect", "imgRegisteredCustomer", "Label0f43418a854134b", "Label0h9f6137078bb41"],
        "retainScrollPosition": false,
        "titleBar": true
    });
};