function addWidgetspopConfirmDelete() {
    var HBox0bd93bd6900d646 = new kony.ui.Box({
        "enableCache": false,
        "id": "HBox0bd93bd6900d646",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var VBox0g599357521a84c = new kony.ui.Box({
        "enableCache": false,
        "id": "VBox0g599357521a84c",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slVbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var Label0j2d5fe6b66be47 = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0j2d5fe6b66be47",
        "isVisible": true,
        "skin": "CopyslLabel0a948306d060449",
        "text": "Info!!"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var Line0a7045b2d89d44b = new kony.ui.Line({
        "enableCache": false,
        "id": "Line0a7045b2d89d44b",
        "isVisible": true,
        "skin": "CopyslLine0fffa4f6ef5f346"
    }, {
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "thickness": 1
    }, {});
    var Label0b9d96edba28d4f = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0b9d96edba28d4f",
        "isVisible": true,
        "skin": "CopyslLabel0fc29375c375a41",
        "text": "Are you sure you want to delete the customer?"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var CopyHBox0aee0dc07aba44e = new kony.ui.Box({
        "enableCache": false,
        "id": "CopyHBox0aee0dc07aba44e",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var btnYes = new kony.ui.Button({
        "enableCache": false,
        "focusSkin": "CopyslButtonGlossBlue0bdffa29cab0c41",
        "id": "btnYes",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0e96a1ee51ede40",
        "text": "Yes"
    }, {
        "containerWeight": 50,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [6, 6, 6, 6],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var btnNo = new kony.ui.Button({
        "enableCache": false,
        "focusSkin": "CopyslButtonGlossRed0c170f4b4aa544b",
        "id": "btnNo",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0i771e200732240",
        "text": "No"
    }, {
        "containerWeight": 50,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [6, 6, 6, 6],
        "marginInPixel": false,
        "padding": [4, 4, 4, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    CopyHBox0aee0dc07aba44e.add(btnYes, btnNo);
    VBox0g599357521a84c.add(Label0j2d5fe6b66be47, Line0a7045b2d89d44b, Label0b9d96edba28d4f, CopyHBox0aee0dc07aba44e);
    HBox0bd93bd6900d646.add(VBox0g599357521a84c);
    popConfirmDelete.add(HBox0bd93bd6900d646);
};

function popConfirmDeleteGlobals() {
    popConfirmDelete = new kony.ui.Popup({
        "addWidgets": addWidgetspopConfirmDelete,
        "enableCache": false,
        "id": "popConfirmDelete",
        "init": AS_Popup_i2f6d0bd52914c8697dbc5630ef44816,
        "isModal": false,
        "skin": "CopyslPopup0j59ca1535ec64d",
        "transparencyBehindThePopup": 70
    }, {
        "containerWeight": 80,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "directChildrenIDs": ["btnNo", "btnYes", "CopyHBox0aee0dc07aba44e", "HBox0bd93bd6900d646", "Label0b9d96edba28d4f", "Label0j2d5fe6b66be47", "Line0a7045b2d89d44b", "VBox0g599357521a84c"],
        "inTransitionConfig": {
            "inTransition": "slidein"
        },
        "mangoMode": true,
        "outTransitionConfig": {
            "outTransition": "slideout"
        }
    });
};