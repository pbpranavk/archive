function addWidgetsfrmDyn() {
    frmDyn.setDefaultUnit(kony.flex.DP);
    var flexParent = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "100%",
        "id": "flexParent",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0fcb5c16c7b5140",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flexParent.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "12%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0j446527802c74d",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var logo = new com.org.amwayLogo.logo({
        "clipBounds": true,
        "enableCache": false,
        "id": "logo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "masterType": constants.MASTER_TYPE_DEFAULT,
        "skin": "CopyslFbox0ef67a12bf4cc4a"
    }, {}, {});
    logo.flxHeader.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.flxHeader.height = "100%";
    flxHeader.add(logo);
    var flxAdd = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableCache": false,
        "enableScrolling": true,
        "height": "88%",
        "horizontalScrollIndicator": true,
        "id": "flxAdd",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "CopyslFSbox0ed4383140ac149",
        "top": "12%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxAdd.setDefaultUnit(kony.flex.DP);
    flxAdd.add();
    flexParent.add(flxHeader, flxAdd);
    var flxBuckets = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "100%",
        "id": "flxBuckets",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0d710c892040646",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxBuckets.setDefaultUnit(kony.flex.DP);
    var flxBucketProspect = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "0%",
        "clipBounds": true,
        "enableCache": false,
        "height": "280dp",
        "id": "flxBucketProspect",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    flxBucketProspect.setDefaultUnit(kony.flex.DP);
    var ImgProspect = new kony.ui.Image2({
        "centerY": "64%",
        "enableCache": false,
        "height": "73dp",
        "id": "ImgProspect",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h9f6137078bb41 = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0h9f6137078bb41",
        "isVisible": true,
        "left": "151dp",
        "skin": "sknLblBottomText",
        "text": "Prospect",
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0f43418a854134b = new kony.ui.Label({
        "enableCache": false,
        "id": "Label0f43418a854134b",
        "isVisible": true,
        "left": "169dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxBucketProspect.add(ImgProspect, Label0h9f6137078bb41, Label0f43418a854134b);
    var CopyflxBucketProspect0f5102205494548 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "1%",
        "clipBounds": true,
        "enableCache": false,
        "height": "280dp",
        "id": "CopyflxBucketProspect0f5102205494548",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f5102205494548.setDefaultUnit(kony.flex.DP);
    var imgCustomer = new kony.ui.Image2({
        "centerY": "62%",
        "enableCache": false,
        "height": "73dp",
        "id": "imgCustomer",
        "isVisible": true,
        "left": "24%",
        "right": "30%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0b7eb7a6af8b444 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0b7eb7a6af8b444",
        "isVisible": true,
        "left": "52dp",
        "skin": "sknLblBottomText",
        "text": "Customer",
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0e911c1264c4e4c = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0e911c1264c4e4c",
        "isVisible": true,
        "left": "88dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "top": "170dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0f5102205494548.add(imgCustomer, CopyLabel0b7eb7a6af8b444, CopyLabel0e911c1264c4e4c);
    var CopyflxBucketProspect0f2f6d40304a94f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "100%",
        "clipBounds": true,
        "enableCache": false,
        "height": "290dp",
        "id": "CopyflxBucketProspect0f2f6d40304a94f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f2f6d40304a94f.setDefaultUnit(kony.flex.DP);
    var imgRegisteredCustomer = new kony.ui.Image2({
        "centerY": "32%",
        "enableCache": false,
        "height": "73dp",
        "id": "imgRegisteredCustomer",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0j97fad3d02f648 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0j97fad3d02f648",
        "isVisible": true,
        "left": "145dp",
        "skin": "sknLblBottomText",
        "text": "Reg Customer",
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0dc9ac6e327e049 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0dc9ac6e327e049",
        "isVisible": true,
        "left": "172dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "top": "89dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0f2f6d40304a94f.add(imgRegisteredCustomer, CopyLabel0j97fad3d02f648, CopyLabel0dc9ac6e327e049);
    var CopyflxBucketProspect0bc4c4a78143f42 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "100%",
        "clipBounds": true,
        "enableCache": false,
        "height": "290dp",
        "id": "CopyflxBucketProspect0bc4c4a78143f42",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "CopyslFbox0b92c41bede774f",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0bc4c4a78143f42.setDefaultUnit(kony.flex.DP);
    var imgABO = new kony.ui.Image2({
        "enableCache": false,
        "height": "73dp",
        "id": "imgABO",
        "isVisible": true,
        "left": "25%",
        "right": "10%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "19%",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0fcf13fc0192541 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0fcf13fc0192541",
        "isVisible": true,
        "left": "83dp",
        "skin": "sknLblBottomText",
        "text": "ABO",
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0h5a7ed6ab01341 = new kony.ui.Label({
        "enableCache": false,
        "id": "CopyLabel0h5a7ed6ab01341",
        "isVisible": true,
        "left": "93dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "top": "90dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    CopyflxBucketProspect0bc4c4a78143f42.add(imgABO, CopyLabel0fcf13fc0192541, CopyLabel0h5a7ed6ab01341);
    flxBuckets.add(flxBucketProspect, CopyflxBucketProspect0f5102205494548, CopyflxBucketProspect0f2f6d40304a94f, CopyflxBucketProspect0bc4c4a78143f42);
    var flxCutter = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerY": "50%",
        "clipBounds": true,
        "enableCache": false,
        "height": "90%",
        "id": "flxCutter",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0dff03ab0509746",
        "top": "97dp",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxCutter.setDefaultUnit(kony.flex.DP);
    var flexAnim = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "enableCache": false,
        "height": "147dp",
        "id": "flexAnim",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "93dp",
        "skin": "flxSkn10",
        "top": "193dp",
        "width": "50%",
        "zIndex": 200
    }, {}, {});
    flexAnim.setDefaultUnit(kony.flex.DP);
    flexAnim.add();
    flxCutter.add(flexAnim);
    frmDyn.add(flexParent, flxBuckets, flxCutter);
};

function frmDynGlobals() {
    frmDyn = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDyn,
        "enableCache": false,
        "enabledForIdleTimeout": false,
        "id": "frmDyn",
        "init": AS_Form_bdc1409a0859409db5283872b12399f6,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0d3b7f4bcd75e49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "animateHeaderFooter": false,
        "directChildrenIDs": ["CopyflxBucketProspect0bc4c4a78143f42", "CopyflxBucketProspect0f2f6d40304a94f", "CopyflxBucketProspect0f5102205494548", "CopyLabel0b7eb7a6af8b444", "CopyLabel0dc9ac6e327e049", "CopyLabel0e911c1264c4e4c", "CopyLabel0fcf13fc0192541", "CopyLabel0h5a7ed6ab01341", "CopyLabel0j97fad3d02f648", "flexAnim", "flexParent", "flxAdd", "flxBucketProspect", "flxBuckets", "flxCutter", "flxHeader", "imgABO", "imgCustomer", "ImgProspect", "imgRegisteredCustomer", "Label0f43418a854134b", "Label0h9f6137078bb41", "logo"],
        "retainScrollPosition": false,
        "titleBar": true
    });
};