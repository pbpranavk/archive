define(function() {
    return function(controller) {
        var logo = new kony.ui.FlexContainer({
            "clipBounds": true,
            "enableCache": false,
            "isMaster": true,
            "height": "100%",
            "id": "logo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "CopyslFbox0e8bb5f48629d4f",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        logo.setDefaultUnit(kony.flex.DP);
        var FlexContainer0a121ffbfff784e = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "enableCache": false,
            "height": "14.68%",
            "id": "FlexContainer0a121ffbfff784e",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "CopyslFbox0c985de522b0a48",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        FlexContainer0a121ffbfff784e.setDefaultUnit(kony.flex.DP);
        var Image0b2f4739993234e = new kony.ui.Image2({
            "enableCache": false,
            "height": "65dp",
            "id": "Image0b2f4739993234e",
            "isVisible": true,
            "left": "105dp",
            "src": "amway1.png",
            "top": "15dp",
            "width": "150dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        FlexContainer0a121ffbfff784e.add(Image0b2f4739993234e);
        logo.add(FlexContainer0a121ffbfff784e);
        return logo;
    }
})