define(function() {
    return function(controller) {
        var logo = new kony.ui.FlexContainer({
            "clipBounds": true,
            "enableCache": false,
            "isMaster": true,
            "height": "100%",
            "id": "logo",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "skin": "CopyslFbox0ef67a12bf4cc4a",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        logo.setDefaultUnit(kony.flex.DP);
        var flxHeader = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "enableCache": false,
            "height": "12%",
            "id": "flxHeader",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0.00%",
            "skin": "CopyslFbox0i22f18daf6a44e",
            "top": "0.02%",
            "width": "100%",
            "zIndex": 3
        }, {}, {});
        flxHeader.setDefaultUnit(kony.flex.DP);
        var imgLogo = new kony.ui.Image2({
            "centerX": "50%",
            "centerY": "50%",
            "enableCache": false,
            "height": "65dp",
            "id": "imgLogo",
            "isVisible": true,
            "left": "105dp",
            "src": "logo.png",
            "top": "13dp",
            "width": "150dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var Image0hed6bdf347444d = new kony.ui.Image2({
            "enableCache": false,
            "height": "40dp",
            "id": "Image0hed6bdf347444d",
            "isVisible": true,
            "left": "294dp",
            "skin": "slImage",
            "src": "tune.png",
            "top": "15dp",
            "width": "70dp",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxHeader.add(imgLogo, Image0hed6bdf347444d);
        logo.add(flxHeader);
        return logo;
    }
})