//startup.js file
var globalhttpheaders = {};
var appConfig = {
    appId: "AmwayCM",
    appName: "AmwayCM",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.20.17.84",
    serverPort: "80",
    secureServerPort: "443",
    isDebug: true,
    middlewareContext: "AmwayCM",
    isMFApp: false,
    url: null,
    secureurl: null
};
sessionID = "";

function appInit(params) {
    skinsInit();
    initializeUserWidgets();
    frmDynGlobals();
    frmEditProfGlobals();
    frmGroupDetailsGlobals();
    frmGroupsGlobals();
    frmHomeGlobals();
    frmStartGlobals();
    frmTempGlobals();
    popConfirmDeleteGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 730190
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    callAppMenu();
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        showstartupform: function() {
            frmDyn.show();
        }
    });
};

function loadResources() {
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
    }
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
};

function onSuccessSDKCallBack() {
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}
kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
//If default locale is specified. This is set even before any other app life cycle event is called.
loadResources();