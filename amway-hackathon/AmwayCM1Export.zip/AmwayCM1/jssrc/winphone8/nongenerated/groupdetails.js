//Type your code here
var gblArrayLength = 0;
var data = [];
var count = 1;
var data1 = [];
var gblCustArr = [];
var gblProsArr = [];
var gblRegCustArr = [];
var gblisAboArr = [];

function groupDetails_init() {
    frmGroupDetails.preShow = frmGroupDetails_preShow;
    frmGroupDetails.postShow = frmGroupDetails_postShow;
    frmGroupDetails.btnProsMore.onClick = frmGroupDetails_btnProsMore_onClick;
    frmGroupDetails.onDeviceBack = frmGroupDetails_onDeviceBack;
}

function frmGroupDetails_btnProsMore_onClick() {
    frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = true;
}

function frmGroupDetails_preShow() {
    frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = false;
    frmGroupDetails.flxContactList.showFadingEdges = false;
    getData();
    genContacts();
}

function frmGroupDetails_postShow() {}

function getData() {
    data = [];
    data1 = kony.contact.find('*', true);
    if (isFromProspects == true) {
        gblProsArr = data1.slice(1, 12);
        data = gblProsArr;
        //isFromProspects = false;    
        frmGroupDetails.lblGroupName.text = "Prospects";
    } else if (isFromCustomers == true) {
        gblCustArr = data1.slice(13, 24);
        data = gblCustArr;
        //isFromCustomers = false;
        frmGroupDetails.lblGroupName.text = "Customers";
    } else if (isFromRegCust == true) {
        gblRegCustArr = data1.slice(25, 37);
        data = gblRegCustArr;
        // isFromRegCust = false;
        frmGroupDetails.lblGroupName.text = "Registered Customers";
    } else if (isFromAbo == true) {
        gblisAboArr = data1.slice(38, 50);
        data = gblisAboArr;
        // isFromAbo = false;
        frmGroupDetails.lblGroupName.text = "Might be an ABO";
    }
    gblArrayLength = data.length;
    kony.print("pranav --> gblArrayLength" + gblArrayLength);
}

function genContacts() {
    kony.print("Savanth ----> Inside Dynamic Flex Creation");
    var flxContacts = [];
    var flxContactDetails1 = [];
    var lblShortName1 = [];
    var lblDummyData1 = [];
    var btnCancel1 = [];
    var btnEdit1 = [];
    var flxContactDetails2 = [];
    var lblShortName2 = [];
    var lblDummyData2 = [];
    var btnMore2 = [];
    var edit2 = [];
    var j = 0;
    for (var i = 0; i < data.length / 2; i++) {
        if (j + 1 <= data.length - 1) {
            if ((data[i].firstname !== undefined) && (data[i + 1].firstname !== undefined)) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails1" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName1" + i,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData1" + i,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel1" + i,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit1" + i,
                    "isVisible": true,
                    "left": "5%",
                    "right": -3,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContactDetails2[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails2" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "50%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails2[i].setDefaultUnit(kony.flex.DP);
                lblShortName2[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName2" + i,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j + 1].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData2[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData2" + i,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j + 1].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnMore2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "height": "15%",
                    "id": "btnMore2" + i,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                edit2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "edit2" + i,
                    "isVisible": true,
                    "left": "9%",
                    "right": 0,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                kony.print("Savanth ---> adding ");
                flxContactDetails2[i].add(lblShortName2[i], lblDummyData2[i], btnMore2[i], edit2[i]);
                flxContacts[i].add(flxContactDetails1[i], flxContactDetails2[i]);
                kony.print("added stuff --> " + JSON.stringify(flxContacts[i]));
                frmGroupDetails.flxContactList.add(flxContacts[i]);
                try {
                    flxContactDetails1[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    flxContactDetails2[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    kony.print("pranav --->Inside try");
                } catch (e) {
                    kony.print("Error" + e);
                }
                kony.print("Savanth --->After  adding ");
            }
        } else {
            kony.print("Inside Odd");
            if (data[i].firstname !== undefined) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails1" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName1" + i,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData1" + i,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel1" + i,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit1" + i,
                    "isVisible": true,
                    "left": "5%",
                    "right": -3,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContacts[i].add(flxContactDetails1[i]);
                frmGroupDetails.flxContactList.add(flxContacts[i]);
            }
        }
        j = j + 2;
    }
    //populateContacts();
}

function splitName(s) {
    var res = [];
    res = s.split(" ");
    var fin = "";
    if (res.length > 1) {
        var i = 1;
        for (; i < res.length; i++) {
            if (res[i].charAt(0) !== '') {
                fin = res[0].charAt(0) + "" + res[i].charAt(0).toUpperCase();
                break;
            }
        }
        if (i === res.length) fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    } else {
        fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    }
    return fin;
}

function randomSkinGene(max, min) {
    if (count === 10) {
        count = 1;
        return 10;
    } else {
        var p = count;
        count++;
        return p;
    }
    //return Math.floor(Math.random() * (max - min + 1)) + min;  	
}

function frmGroupDetails_onDeviceBack() {
    data = [];
    frmGroupDetails.flxContactList.removeAll();
    isFromProspects = false;
    isFromCustomers = false;
    isFromRegCust = false;
    isFromAbo = false;
    frmGroups.show();
}
var flxId = 0;

function deleteContact(source) {
    //alert(source.id);
    var id = source.id;
    var idL = parseInt(id.charAt(id.length - 1));
    var idO = parseInt(id.charAt(id.length - 2));
    idL = idL + 1;
    var mTwo = idL * 2;
    if (idO === 1) flxId = mTwo - 2;
    else flxId = mTwo - 1;
    //alert("value of flxID "+flxId);
    kony.print("gblCustArr is given as " + JSON.stringify(gblCustArr));
    kony.print("splice before odd length " + gblCustArr.length);
    popConfirmDelete.show();
}
//prospect handling for delete
function popup_callback() {
    if (isFromProspects == true) {
        kony.print("harsha --> inside prospects");
        gblProsArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblProsArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblProsArr;
        kony.print("splice before odd length data length is " + data.length);
        genContacts();
    }
    //customer handling for delete  
    else if (isFromCustomers == true) {
        kony.print("harsha --> inside customers");
        gblCustArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblCustArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblCustArr;
        kony.print("splice before odd length data length is " + data.length);
        genContacts();
    }
    //registered customer handling for delete
    else if (isFromRegCust == true) {
        kony.print("harsha --> inside registered customers");
        gblRegCustArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblRegCustArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblRegCustArr;
        kony.print("splice before odd length data length is " + data.length);
        genContacts();
    }
    //Might be an ABO handling for delete  
    else if (isFromAbo == true) {
        kony.print("harsha --> inside abo");
        gblisAboArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblisAboArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblisAboArr;
        kony.print("splice before odd length data length is " + data.length);
        genContacts();
    }
    popConfirmDelete.dismiss();
}