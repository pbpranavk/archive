var isFromProspects = false;
var isFromCustomers = false;
var isFromRegCust = false;
var isFromAbo = false;
//Type your code here
/*var data = [];
var count=1;
function form_Int(){
  frmDyn.preShow = getData;
  frmDyn.postShow = genContacts;

}
function getData(){
  data  =  kony.contact.find('*',true);
}
function genContacts(){
  kony.print("Savanth ----> Inside Dynamic Flex Creation");
  var flxContacts = [];
  var flxContactDetails1 = [];
  var lblShortName1 =[];
  var  lblDummyData1 = [];
  var btnCancel1 = [];
  var btnEdit1 = [];
  
  var flxContactDetails2 = [];
  var lblShortName2 = [];
  var lblDummyData2 = [];
  var btnMore2 = [];
  var edit2 = [];
  for(var i=0;i<data.length/2;i++){
  if((data[i].firstname !== undefined ) && (data[i+1].firstname !== undefined )){
    flxContacts[i] = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "20%",
        "id": "flxParent"+i,
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "skin": "CopyslFbox0b497ce58c87643"
    }, {}, {});
    flxContacts[i].setDefaultUnit(kony.flex.DP);
    flxContactDetails1[i] = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxContactDetails1"+i,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "1%",
        "skin": "flxSkn"+randomSkinGene(10,1),
        "top": "2%",
        "width": "47%",
        "zIndex": 1
    }, {}, {});
    flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
    lblShortName1[i] = new kony.ui.Label({
        "bottom": "25%",
        "centerX": "50%",
        "id": "lblShortName1"+i,
        "isVisible": true,
        "left": "30%",
        "skin": "CopyslLabel0fd1a2355e6fb4d",
        "text":data[i].firstname ,
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    lblDummyData1[i] = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblDummyData1"+i,
        "isVisible": true,
        "left": "44dp",
        "skin": "CopyslLabel0b98410a6393644",
        "text": splitName(data[i].firstname),
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    btnCancel1[i] = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
        "height": "15%",
        "id": "btnCancel1"+i,
        "isVisible": true,
        "right": "7%",
        "skin": "CopyslButtonGlossBlue0h39742e7dce949",
        
        "top": "10%",
        "width": "9%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    btnEdit1[i] = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
        "height": "15%",
        "id": "btnEdit1"+i,
        "isVisible": true,
        "left": "5%",
        "right": -3,
        "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
        
        "top": "10%",
        "width": "9%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
    flxContactDetails2[i] = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxContactDetails2"+i,
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "1%",
        "skin": "flxSkn"+randomSkinGene(10,1),
        "top": "2%",
        "width": "50%",
        "zIndex": 1
    }, {}, {});
    flxContactDetails2[i].setDefaultUnit(kony.flex.DP);
    lblShortName2[i] = new kony.ui.Label({
        "bottom": "25%",
        "centerX": "50%",
        "id": "lblShortName2"+i,
        "isVisible": true,
        "left": "30%",
        "skin": "CopyslLabel0fd1a2355e6fb4d",
        "text":data[i+1].firstname,
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    lblDummyData2[i] = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblDummyData2"+i,
        "isVisible": true,
        "left": "44dp",
        "skin": "CopyslLabel0b98410a6393644",
        "text": splitName(data[i+1].firstname),
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    btnMore2[i] = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0a90686d42b7541",
        "height": "15%",
        "id": "btnMore2"+i,
        "isVisible": true,
        "right": "7%",
        "skin": "CopyslButtonGlossBlue0a90686d42b7541",
        
        "top": "10%",
        "width": "9%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    edit2[i] = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
        "height": "15%",
        "id": "edit2"+i,
        "isVisible": true,
        "left": "9%",
        "right": 0,
        "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
        
        "top": "10%",
        "width": "9%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kony.print("Savanth ---> adding ");
    flxContactDetails2[i].add(lblShortName2[i], lblDummyData2[i], btnMore2[i], edit2[i]);
    flxContacts[i].add(flxContactDetails1[i], flxContactDetails2[i]);
	frmDyn.add(flxContacts[i]);
    kony.print("Savanth --->After  adding ");
  }
  }
  //populateContacts();
}

/*
function populateContacts(){
  kony.print("pranav --->Inside populating contacts");
    for(var i=0;i<(data.length)/2;i++){    
    kony.print("Pranav ---> d is"+d);
    kony.print("Harsha ---> data[d] is"+data[d]);
    kony.print("Harsha ---> data[d+1] is"+data[d+1]);
  
    if((data[d].firstname !== undefined ) && (data[d+1].firstname !== undefined ))
      if(d+1 <= data.length-1 ){
      kony.print("Savanth ---> Inside Even");
      var flxP = "flxParent"+i;
      var flxCD1 = "flxContactDetails1"+i;
      var lblSN1 = "lblShortName1"+i;
      var lblDD1 = "lblDummyData1"+i;
      var flxCD2 = "flxContactDetails2"+i;
      var lblSN2 = "lblShortName2"+i;
      var lblDD2 = "lblDummyData2"+i;
        
        flxParent i .flxContactDetails1 i .lblShortName1 itext:splitName(data[d].firstname)},
         lblDummyData2 : {text:splitName(data[d+1].firstname)},
         lblShortName1 : {text: data[d].firstname},
		 lblShortName2 : {text: data[d+1].firstname},
         flxContactDetails1 : {"skin" : "flxSkn"+randomSkinGene(10,1) },
         flxContactDetails2 : {"skin" : "flxSkn"+randomSkinGene(10,1) }
        ;   
    }else{
       kony.print("Savanth ---> Inside Odd");
      TempArray.push({
		lblDummyData1 : {text:splitName(data[d].firstname)},        
         lblShortName1 : {text: data[d].firstname},
        flxContactDetails2 : {isVisible:false} 
      });
    }
     
      d=d+2;
  }
}
*/
function splitName(s) {
    var res = [];
    res = s.split(" ");
    var fin = "";
    if (res.length > 1) {
        var i = 1;
        for (; i < res.length; i++) {
            if (res[i].charAt(0) !== '') {
                fin = res[0].charAt(0) + "" + res[i].charAt(0).toUpperCase();
                break;
            }
        }
        if (i === res.length) fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    } else {
        fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    }
    return fin;
}

function randomSkinGene(max, min) {
    if (count === 10) {
        count = 1;
        return 10;
    } else {
        var p = count;
        count++;
        return p;
    }
    //return Math.floor(Math.random() * (max - min + 1)) + min;  	
}

function frmGroups_init() {
    frmGroups.preShow = frmGroups_preShow;
    //  frmGroups.postShow = frmGroups_postShow;
    frmGroups.btnProspects.onClick = frmGroups_btnProspects_onClick;
    frmGroups.btnCust.onClick = frmGroups_btnCust_onClick;
    frmGroups.btnReg.onClick = frmGroups_btnReg_onClick;
    frmGroups.btnAbo.onClick = frmGroups_btnAbo_onClick;
}

function frmGroups_preShow() {
    frmGroups.flxHighlight1.isVisible = false;
}

function frmGroups_btnProspects_onClick() {
    isFromProspects = true;
    frmGroupDetails.show();
}

function frmGroups_btnCust_onClick() {
    isFromCustomers = true;
    frmGroupDetails.show();
}

function frmGroups_btnReg_onClick() {
    isFromRegCust = true;
    frmGroupDetails.show();
}

function frmGroups_btnAbo_onClick() {
    isFromAbo = true;
    frmGroupDetails.show();
}