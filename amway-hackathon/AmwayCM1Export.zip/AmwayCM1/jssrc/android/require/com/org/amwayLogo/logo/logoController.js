define(function() {
    var controller = require("com/org/amwayLogo/logo/userlogoController");
    var actions = require("com/org/amwayLogo/logo/logoControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});