define(function() {
    var controller = require("com/org/amway/logo/userlogoController");
    var actions = require("com/org/amway/logo/logoControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});