function addWidgetsfrmEditProf() {
    frmEditProf.setDefaultUnit(kony.flex.DP);
    var flxProPic = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "clipBounds": true,
        "height": "15%",
        "id": "flxProPic",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0dd5e5c33e36044",
        "top": "4%",
        "width": "25%",
        "zIndex": 10
    }, {}, {});
    flxProPic.setDefaultUnit(kony.flex.DP);
    var imgProPic = new kony.ui.Image2({
        "height": "100%",
        "id": "imgProPic",
        "isVisible": false,
        "left": "0dp",
        "src": "scooby.jpg",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblProPic = new kony.ui.Label({
        "centerX": "50%",
        "height": "100%",
        "id": "lblProPic",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0bc68047ae36242",
        "text": "ST",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [27, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxProPic.add(imgProPic, lblProPic);
    var flxBg = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "13%",
        "id": "flxBg",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0e8d463c13c224f",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxBg.setDefaultUnit(kony.flex.DP);
    flxBg.add();
    var btnCall = new kony.ui.Button({
        "height": "9%",
        "id": "btnCall",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslButtonGlossBlue0ed51747e1c5c4f",
        "top": "8%",
        "width": "15%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMail = new kony.ui.Button({
        "height": "9%",
        "id": "btnMail",
        "isVisible": true,
        "left": "15%",
        "skin": "CopyslButtonGlossBlue0cea9bbaa19f14b",
        "top": "8%",
        "width": "15%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxName = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10.03%",
        "id": "flxName",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "skin": "CopyslFbox0ab7cbb122b0448",
        "top": "18%",
        "width": "100%",
        "zIndex": 10
    }, {}, {});
    flxName.setDefaultUnit(kony.flex.DP);
    var lblName = new kony.ui.Label({
        "height": "25%",
        "id": "lblName",
        "isVisible": true,
        "left": "6%",
        "skin": "CopyslLabel0jb6f9539945143",
        "text": "Name",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var tbxName = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "50%",
        "id": "tbxName",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "9%",
        "placeholder": "Enter Your Name",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0iaeabdb4fc4343",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0%",
        "width": "260dp",
        "zIndex": 10
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblLine1 = new kony.ui.Label({
        "height": "3px",
        "id": "lblLine1",
        "isVisible": true,
        "left": "24dp",
        "skin": "CopyslLabel0g3568028ecc849",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "90%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxName.add(lblName, tbxName, lblLine1);
    var flxPhNo = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10.03%",
        "id": "flxPhNo",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyslFbox0a556fa20b4344f",
        "top": "28%",
        "width": "100%",
        "zIndex": 10
    }, {}, {});
    flxPhNo.setDefaultUnit(kony.flex.DP);
    var lblPhno = new kony.ui.Label({
        "height": "25%",
        "id": "lblPhno",
        "isVisible": true,
        "left": "6%",
        "skin": "CopyslLabel0jb6f9539945143",
        "text": "Phone",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var tbxPhone = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "50%",
        "id": "tbxPhone",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "9%",
        "placeholder": "Enter Your Phone Number",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0iaeabdb4fc4343",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
        "top": "0%",
        "width": "260dp",
        "zIndex": 10
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblLine2 = new kony.ui.Label({
        "height": "3px",
        "id": "lblLine2",
        "isVisible": true,
        "left": "24dp",
        "skin": "CopyslLabel0g3568028ecc849",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "90%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxPhNo.add(lblPhno, tbxPhone, lblLine2);
    var flxEmail = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10.03%",
        "id": "flxEmail",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyslFbox0a556fa20b4344f",
        "top": "38%",
        "width": "100%",
        "zIndex": 10
    }, {}, {});
    flxEmail.setDefaultUnit(kony.flex.DP);
    var lblEmail = new kony.ui.Label({
        "height": "25%",
        "id": "lblEmail",
        "isVisible": true,
        "left": "6%",
        "skin": "CopyslLabel0jb6f9539945143",
        "text": "Email",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var tbxEmail = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "50%",
        "id": "tbxEmail",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_EMAIL,
        "left": "9.03%",
        "placeholder": "Enter Your Email id",
        "secureTextEntry": false,
        "skin": "CopyslTextBox0iaeabdb4fc4343",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0.00%",
        "width": "260dp",
        "zIndex": 10
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var lblLine3 = new kony.ui.Label({
        "height": "3px",
        "id": "lblLine3",
        "isVisible": true,
        "left": "24dp",
        "skin": "CopyslLabel0g3568028ecc849",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "90%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxEmail.add(lblEmail, tbxEmail, lblLine3);
    var flxAddress = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "26.56%",
        "id": "flxAddress",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyslFbox0a556fa20b4344f",
        "top": "45%",
        "width": "100%",
        "zIndex": 10
    }, {}, {});
    flxAddress.setDefaultUnit(kony.flex.DP);
    var lblAdress = new kony.ui.Label({
        "height": "25%",
        "id": "lblAdress",
        "isVisible": true,
        "left": "6%",
        "skin": "CopyslLabel0jb6f9539945143",
        "text": "Adress",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var txtAreAddress = new kony.ui.TextArea2({
        "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
        "id": "txtAreAddress",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
        "left": "8%",
        "numberOfVisibleLines": 3,
        "placeholder": "Address goes here",
        "skin": "slTextArea",
        "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
        "top": "0dp",
        "width": "90%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
        "padding": [2, 2, 2, 2],
        "paddingInPixel": false
    }, {});
    flxAddress.add(lblAdress, txtAreAddress);
    var flxHeat = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxHeat",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "top": "72%",
        "width": "100%",
        "zIndex": 10
    }, {}, {});
    flxHeat.setDefaultUnit(kony.flex.DP);
    var hotnessSlider = new kony.ui.Slider({
        "height": "20%",
        "id": "hotnessSlider",
        "isVisible": true,
        "left": "13%",
        "leftSkin": "CopyslSliderLeftBlue0c4a412ae84fb46",
        "max": 100,
        "min": 0,
        "rightSkin": "slSliderRightBlue",
        "selectedValue": 40,
        "step": 1,
        "thumbImage": "slider_android.png",
        "top": "45%",
        "width": "70%",
        "zIndex": 1
    }, {}, {
        "thickness": 15
    });
    var lblCold = new kony.ui.Label({
        "id": "lblCold",
        "isVisible": true,
        "left": "10%",
        "skin": "CopyslLabel0ca4cf88b1e364a",
        "text": "Cold Prospect",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "60%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblHot = new kony.ui.Label({
        "id": "lblHot",
        "isVisible": true,
        "left": "70%",
        "skin": "CopyslLabel0a7b5b1601ea149",
        "text": "Hot Prospect",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "63%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxHeat.add(hotnessSlider, lblCold, lblHot);
    var btnSave = new kony.ui.Button({
        "height": "9%",
        "id": "btnSave",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslButtonGlossBlue0f594cd3899c14f",
        "text": "Save",
        "top": "91%",
        "width": "100%",
        "zIndex": 10
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmEditProf.add(flxProPic, flxBg, btnCall, btnMail, flxName, flxPhNo, flxEmail, flxAddress, flxHeat, btnSave);
};

function frmEditProfGlobals() {
    frmEditProf = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmEditProf,
        "enabledForIdleTimeout": false,
        "id": "frmEditProf",
        "init": AS_Form_ba9afd4cb19849b0bde1211ca0dd96dd,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0a679159141ea46"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};