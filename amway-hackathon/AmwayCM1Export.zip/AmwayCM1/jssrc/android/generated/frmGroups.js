function addWidgetsfrmGroups() {
    frmGroups.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0j446527802c74d",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var logo = new com.org.amwayLogo.logo({
        "clipBounds": true,
        "id": "logo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "masterType": constants.MASTER_TYPE_DEFAULT,
        "skin": "CopyslFbox0ef67a12bf4cc4a"
    }, {}, {});
    logo.flxHeader.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.flxHeader.height = "100%";
    flxHeader.add(logo);
    var flx = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "6%",
        "id": "flx",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0.00%",
        "skin": "slFbox",
        "top": "12.50%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flx.setDefaultUnit(kony.flex.DP);
    var btnContacts = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0b8bee671c66541",
        "height": "100%",
        "id": "btnContacts",
        "isVisible": true,
        "skin": "sknbtnContacts",
        "text": "Contacts",
        "width": "48%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnGroups = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "99%",
        "id": "btnGroups",
        "isVisible": true,
        "left": "48.70%",
        "skin": "CopyslButtonGlossBlue0bf7532741aa845",
        "text": "Groups",
        "top": "0.00%",
        "width": "52%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyflxHighlight0f94c28dcf2c545 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "CopyflxHighlight0f94c28dcf2c545",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "48%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "0%",
        "width": "0.70%",
        "zIndex": 1
    }, {}, {});
    CopyflxHighlight0f94c28dcf2c545.setDefaultUnit(kony.flex.DP);
    CopyflxHighlight0f94c28dcf2c545.add();
    flx.add(btnContacts, btnGroups, CopyflxHighlight0f94c28dcf2c545);
    var flxScroller = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": false,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "397dp",
        "horizontalScrollIndicator": true,
        "id": "flxScroller",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "19.50%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxScroller.setDefaultUnit(kony.flex.DP);
    var flxInnerGrps = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "85%",
        "id": "flxInnerGrps",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "top": "0%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxInnerGrps.setDefaultUnit(kony.flex.DP);
    var flxPros = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxPros",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "flxSkn1",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxPros.setDefaultUnit(kony.flex.DP);
    var btnProspects = new kony.ui.Button({
        "height": "100%",
        "id": "btnProspects",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore1 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore1",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxPros.add(btnProspects, btnMore1);
    var flxCust = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxCust",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "flxSkn2",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxCust.setDefaultUnit(kony.flex.DP);
    var btnCust = new kony.ui.Button({
        "height": "100%",
        "id": "btnCust",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Customers",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore2 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore2",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCust.add(btnCust, btnMore2);
    var flxreg = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxreg",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "flxSkn4",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxreg.setDefaultUnit(kony.flex.DP);
    var btnReg = new kony.ui.Button({
        "height": "100%",
        "id": "btnReg",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Registered Customers",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore3 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore3",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxreg.add(btnReg, btnMore3);
    var flxABO = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxABO",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "flxSkn7",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxABO.setDefaultUnit(kony.flex.DP);
    var btnAbo = new kony.ui.Button({
        "height": "100%",
        "id": "btnAbo",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "ABO",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore4 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore4",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxABO.add(btnAbo, btnMore4);
    var flxcust1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxcust1",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "flxSkn1",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxcust1.setDefaultUnit(kony.flex.DP);
    var btn1 = new kony.ui.Button({
        "height": "100%",
        "id": "btn1",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore5 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore5",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxcust1.add(btn1, btnMore5);
    var flxcust2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxcust2",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "flxSkn1",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxcust2.setDefaultUnit(kony.flex.DP);
    var btn2 = new kony.ui.Button({
        "height": "100%",
        "id": "btn2",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore6 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore6",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxcust2.add(btn2, btnMore6);
    var flxcust3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxcust3",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "-100%",
        "skin": "flxSkn1",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxcust3.setDefaultUnit(kony.flex.DP);
    var btn3 = new kony.ui.Button({
        "height": "100%",
        "id": "btn3",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore7 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore7",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxcust3.add(btn3, btnMore7);
    var flxcust4 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "15%",
        "id": "flxcust4",
        "isVisible": false,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "100%",
        "skin": "flxSkn1",
        "top": "2%",
        "width": "98%",
        "zIndex": 1
    }, {}, {});
    flxcust4.setDefaultUnit(kony.flex.DP);
    var btn4 = new kony.ui.Button({
        "height": "100%",
        "id": "btn4",
        "isVisible": true,
        "left": "2.00%",
        "skin": "CopyslButtonGlossBlue0ec7db85a8b7745",
        "text": "Prospects",
        "top": "0%",
        "width": "85%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnMore8 = new kony.ui.Button({
        "height": "100.00%",
        "id": "btnMore8",
        "isVisible": true,
        "left": "2%",
        "skin": "CopyslButtonGlossBlue0c9640e7c57454c",
        "text": "+",
        "top": "0dp",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxcust4.add(btn4, btnMore8);
    flxInnerGrps.add(flxPros, flxCust, flxreg, flxABO, flxcust1, flxcust2, flxcust3, flxcust4);
    flxScroller.add(flxInnerGrps);
    var flxSeperator = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "0.60%",
        "id": "flxSeperator",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0h127445ce8464e",
        "top": "12%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxSeperator.setDefaultUnit(kony.flex.DP);
    flxSeperator.add();
    var flxHighlight1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "0.60%",
        "id": "flxHighlight1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "49%",
        "skin": "CopyslFbox0c30000473b9040",
        "top": "18.30%",
        "width": "52%",
        "zIndex": 1
    }, {}, {});
    flxHighlight1.setDefaultUnit(kony.flex.DP);
    flxHighlight1.add();
    var imgCreateCustom = new kony.ui.Image2({
        "height": "57dp",
        "id": "imgCreateCustom",
        "isVisible": true,
        "left": "78.67%",
        "src": "group.png",
        "top": "88.04%",
        "width": "63dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxCreateGroup = new kony.ui.FlexContainer({
        "centerX": "50%",
        "centerY": "50%",
        "clipBounds": true,
        "height": "220dp",
        "id": "flxCreateGroup",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "37dp",
        "skin": "CopyslFbox0b0e63659929741",
        "top": "220dp",
        "width": "81.48%",
        "zIndex": 1
    }, {}, {});
    flxCreateGroup.setDefaultUnit(kony.flex.DP);
    var txtName = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerX": "50%",
        "centerY": "50%",
        "height": "40dp",
        "id": "txtName",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "20dp",
        "placeholder": "Enter Group Name",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "80dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoFilter": false,
        "keyboardActionLabel": constants.TEXTBOX_KEYBOARD_LABEL_DEFAULT,
        "viewType": constants.TEXTBOX_VIEW_TYPE_DEFAULT
    });
    var btnSubmit = new kony.ui.Button({
        "centerX": "50%",
        "centerY": "80%",
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "btnSubmit",
        "isVisible": true,
        "left": "77dp",
        "skin": "CopyslButtonGlossBlue0a631242078c941",
        "text": "Create",
        "top": "130dp",
        "width": "136dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCreateGroup.add(txtName, btnSubmit);
    frmGroups.add(flxHeader, flx, flxScroller, flxSeperator, flxHighlight1, imgCreateCustom, flxCreateGroup);
};

function frmGroupsGlobals() {
    frmGroups = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmGroups,
        "enabledForIdleTimeout": false,
        "id": "frmGroups",
        "init": AS_Form_b68bd7768f874a96b4c5937cb01763b5,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "postShow": AS_Form_i84459361419498e81f25186a0d12993,
        "skin": "CopyslForm0bf4f198a6d174a"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};