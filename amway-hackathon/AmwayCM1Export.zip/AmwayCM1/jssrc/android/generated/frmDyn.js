function addWidgetsfrmDyn() {
    frmDyn.setDefaultUnit(kony.flex.DP);
    var flexParent = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flexParent",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0fcb5c16c7b5140",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flexParent.setDefaultUnit(kony.flex.DP);
    var flxHeader = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "12%",
        "id": "flxHeader",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0j446527802c74d",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxHeader.setDefaultUnit(kony.flex.DP);
    var logo = new com.org.amwayLogo.logo({
        "clipBounds": true,
        "id": "logo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "masterType": constants.MASTER_TYPE_DEFAULT,
        "skin": "CopyslFbox0ef67a12bf4cc4a"
    }, {}, {});
    logo.flxHeader.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.flxHeader.height = "100%";
    flxHeader.add(logo);
    var flxAdd = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "76%",
        "horizontalScrollIndicator": true,
        "id": "flxAdd",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "CopyslFSbox0ed4383140ac149",
        "top": "19.40%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxAdd.setDefaultUnit(kony.flex.DP);
    flxAdd.add();
    var flxHighlight1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "0.60%",
        "id": "flxHighlight1",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "18.30%",
        "width": "48%",
        "zIndex": 1
    }, {}, {});
    flxHighlight1.setDefaultUnit(kony.flex.DP);
    flxHighlight1.add();
    var flx = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "6%",
        "id": "flx",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "-0.03%",
        "skin": "slFbox",
        "top": "12.48%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flx.setDefaultUnit(kony.flex.DP);
    var btnContacts = new kony.ui.Button({
        "height": "100%",
        "id": "btnContacts",
        "isVisible": true,
        "left": "0.03%",
        "skin": "CopyslButtonGlossBlue0ed4f0b66999a4e",
        "text": "Contacts",
        "top": "0.30%",
        "width": "48%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnGroups = new kony.ui.Button({
        "height": "99%",
        "id": "btnGroups",
        "isVisible": true,
        "left": "48.70%",
        "skin": "CopyslButtonGlossBlue0i94e6e8ba4754e",
        "text": "Groups",
        "top": "0%",
        "width": "52%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flx.add(btnContacts, btnGroups);
    flexParent.add(flxHeader, flxAdd, flxHighlight1, flx);
    var flxBuckets = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBuckets",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox0d710c892040646",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxBuckets.setDefaultUnit(kony.flex.DP);
    var flxBucketProspect = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "0%",
        "clipBounds": true,
        "height": "280dp",
        "id": "flxBucketProspect",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    flxBucketProspect.setDefaultUnit(kony.flex.DP);
    var ImgProspect = new kony.ui.Image2({
        "centerY": "64%",
        "height": "73dp",
        "id": "ImgProspect",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h9f6137078bb41 = new kony.ui.Label({
        "id": "Label0h9f6137078bb41",
        "isVisible": true,
        "left": "151dp",
        "skin": "sknLblBottomText",
        "text": "Prospect",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Label0f43418a854134b = new kony.ui.Label({
        "id": "Label0f43418a854134b",
        "isVisible": true,
        "left": "169dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxBucketProspect.add(ImgProspect, Label0h9f6137078bb41, Label0f43418a854134b);
    var CopyflxBucketProspect0f5102205494548 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "1%",
        "clipBounds": true,
        "height": "280dp",
        "id": "CopyflxBucketProspect0f5102205494548",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f5102205494548.setDefaultUnit(kony.flex.DP);
    var imgCustomer = new kony.ui.Image2({
        "centerY": "62%",
        "height": "73dp",
        "id": "imgCustomer",
        "isVisible": true,
        "left": "24%",
        "right": "30%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0b7eb7a6af8b444 = new kony.ui.Label({
        "id": "CopyLabel0b7eb7a6af8b444",
        "isVisible": true,
        "left": "52dp",
        "skin": "sknLblBottomText",
        "text": "Customer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0e911c1264c4e4c = new kony.ui.Label({
        "id": "CopyLabel0e911c1264c4e4c",
        "isVisible": true,
        "left": "88dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "170dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0f5102205494548.add(imgCustomer, CopyLabel0b7eb7a6af8b444, CopyLabel0e911c1264c4e4c);
    var CopyflxBucketProspect0f2f6d40304a94f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "100%",
        "clipBounds": true,
        "height": "290dp",
        "id": "CopyflxBucketProspect0f2f6d40304a94f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f2f6d40304a94f.setDefaultUnit(kony.flex.DP);
    var imgRegisteredCustomer = new kony.ui.Image2({
        "centerY": "32%",
        "height": "73dp",
        "id": "imgRegisteredCustomer",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0j97fad3d02f648 = new kony.ui.Label({
        "id": "CopyLabel0j97fad3d02f648",
        "isVisible": true,
        "left": "145dp",
        "skin": "sknLblBottomText",
        "text": "Reg Customer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0dc9ac6e327e049 = new kony.ui.Label({
        "id": "CopyLabel0dc9ac6e327e049",
        "isVisible": true,
        "left": "172dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "89dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0f2f6d40304a94f.add(imgRegisteredCustomer, CopyLabel0j97fad3d02f648, CopyLabel0dc9ac6e327e049);
    var CopyflxBucketProspect0bc4c4a78143f42 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "100%",
        "clipBounds": true,
        "height": "290dp",
        "id": "CopyflxBucketProspect0bc4c4a78143f42",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0bc4c4a78143f42.setDefaultUnit(kony.flex.DP);
    var imgABO = new kony.ui.Image2({
        "height": "73dp",
        "id": "imgABO",
        "isVisible": true,
        "left": "25%",
        "right": "10%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "19%",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0fcf13fc0192541 = new kony.ui.Label({
        "id": "CopyLabel0fcf13fc0192541",
        "isVisible": true,
        "left": "83dp",
        "skin": "sknLblBottomText",
        "text": "ABO",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyLabel0h5a7ed6ab01341 = new kony.ui.Label({
        "id": "CopyLabel0h5a7ed6ab01341",
        "isVisible": true,
        "left": "93dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "text": "22",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "90dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0bc4c4a78143f42.add(imgABO, CopyLabel0fcf13fc0192541, CopyLabel0h5a7ed6ab01341);
    flxBuckets.add(flxBucketProspect, CopyflxBucketProspect0f5102205494548, CopyflxBucketProspect0f2f6d40304a94f, CopyflxBucketProspect0bc4c4a78143f42);
    var lblNote = new kony.ui.Label({
        "bottom": 0,
        "height": "4%",
        "id": "lblNote",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0cdc35ff3359446",
        "text": "Note: Long Press any contact to add to a group",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    frmDyn.add(flexParent, flxBuckets, lblNote);
};

function frmDynGlobals() {
    frmDyn = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDyn,
        "enabledForIdleTimeout": false,
        "id": "frmDyn",
        "init": AS_Form_bdc1409a0859409db5283872b12399f6,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0d3b7f4bcd75e49"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};