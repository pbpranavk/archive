function addWidgetsfrmGroupDetails() {
    frmGroupDetails.setDefaultUnit(kony.flex.DP);
    var logo = new com.org.amwayLogo.logo({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9%",
        "id": "logo",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "masterType": constants.MASTER_TYPE_DEFAULT,
        "skin": "CopyslFbox0ef67a12bf4cc4a",
        "top": "0dp"
    }, {}, {});
    logo.Image0hed6bdf347444d.left = "289dp";
    logo.Image0hed6bdf347444d.top = "7dp";
    logo.flxHeader.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.flxHeader.height = "100%";
    logo.autogrowMode = kony.flex.AUTOGROW_NONE;
    logo.height = "9%";
    logo.left = "0dp";
    logo.top = "0dp";
    var flx = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "9.67%",
        "id": "flx",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0.00%",
        "top": "12%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flx.setDefaultUnit(kony.flex.DP);
    var FlexScrollContainer0iaaf625f038149 = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "220dp",
        "horizontalScrollIndicator": true,
        "id": "FlexScrollContainer0iaaf625f038149",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "26dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "194dp",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    FlexScrollContainer0iaaf625f038149.setDefaultUnit(kony.flex.DP);
    FlexScrollContainer0iaaf625f038149.add();
    var Button0db5c8980cadb44 = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossRed0b8bee671c66541",
        "height": "99%",
        "id": "Button0db5c8980cadb44",
        "isVisible": true,
        "skin": "sknbtnContacts",
        "text": "Contacts",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h7544ba940654d = new kony.ui.Label({
        "height": "100%",
        "id": "Label0h7544ba940654d",
        "isVisible": true,
        "left": "49%",
        "skin": "CopyslLabel0e0e014afb8bd44",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0%",
        "width": "3dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var CopyButton0j697f3c759984e = new kony.ui.Button({
        "height": "99%",
        "id": "CopyButton0j697f3c759984e",
        "isVisible": true,
        "left": "50%",
        "skin": "CopyslButtonGlossBlue0bf7532741aa845",
        "text": "Groups",
        "top": "0.00%",
        "width": "50%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flx.add(FlexScrollContainer0iaaf625f038149, Button0db5c8980cadb44, Label0h7544ba940654d, CopyButton0j697f3c759984e);
    var flxHighlight1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "3dp",
        "id": "flxHighlight1",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "21.57%",
        "width": "49%",
        "zIndex": 1
    }, {}, {});
    flxHighlight1.setDefaultUnit(kony.flex.DP);
    flxHighlight1.add();
    var flxHighlight2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "3dp",
        "id": "flxHighlight2",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "50%",
        "skin": "CopyslFbox0cd34a615564c44",
        "top": "21.57%",
        "width": "50%",
        "zIndex": 1
    }, {}, {});
    flxHighlight2.setDefaultUnit(kony.flex.DP);
    flxHighlight2.add();
    var flxGroupTitle = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "7%",
        "id": "flxGroupTitle",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0ed1d694ad5b341",
        "top": "9%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxGroupTitle.setDefaultUnit(kony.flex.DP);
    var lblGroupName = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "id": "lblGroupName",
        "isVisible": true,
        "left": "32%",
        "skin": "CopyslLabel0c8447afbeee248",
        "text": "Customers",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "25%",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var btnProsMore = new kony.ui.Button({
        "centerY": "50%",
        "height": "70%",
        "id": "btnProsMore",
        "isVisible": false,
        "left": "87%",
        "skin": "CopyslButtonGlossBlue0b3d561ea402f4d",
        "top": "3%",
        "width": "10%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxGroupTitle.add(lblGroupName, btnProsMore);
    var FlexContainer0ed33cd570c734c = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "47dp",
        "id": "FlexContainer0ed33cd570c734c",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "225dp",
        "top": "116dp",
        "width": "37.04%",
        "zIndex": 1
    }, {}, {});
    FlexContainer0ed33cd570c734c.setDefaultUnit(kony.flex.DP);
    var btnAddPeople = new kony.ui.Button({
        "height": "50dp",
        "id": "btnAddPeople",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslButtonGlossBlue0f822c585bac14c",
        "text": "Add More",
        "top": "0dp",
        "width": "137dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0ed33cd570c734c.add(btnAddPeople);
    var flxContactList = new kony.ui.FlexScrollContainer({
        "allowHorizontalBounce": false,
        "allowVerticalBounce": true,
        "bounces": true,
        "clipBounds": true,
        "enableScrolling": true,
        "height": "81%",
        "horizontalScrollIndicator": true,
        "id": "flxContactList",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0dp",
        "pagingEnabled": false,
        "scrollDirection": kony.flex.SCROLL_VERTICAL,
        "skin": "slFSbox",
        "top": "19%",
        "verticalScrollIndicator": true,
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxContactList.setDefaultUnit(kony.flex.DP);
    flxContactList.add();
    frmGroupDetails.add(logo, flx, flxHighlight1, flxHighlight2, flxGroupTitle, FlexContainer0ed33cd570c734c, flxContactList);
};

function frmGroupDetailsGlobals() {
    frmGroupDetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmGroupDetails,
        "enabledForIdleTimeout": false,
        "id": "frmGroupDetails",
        "init": AS_Form_d15de87c8c6f42cbb4bed10f9c9e0d35,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0aec07bf5d7444e"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};