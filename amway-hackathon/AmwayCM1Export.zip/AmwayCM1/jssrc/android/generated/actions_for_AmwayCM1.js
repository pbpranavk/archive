//actions.js file 
function AS_Button_i2b0da6426f3475eaad9c639304bcbf6(eventobject) {}

function AS_FlexContainer_a6416ccda57f4f73b45e203c442c5f66(eventobject, x, y) {}

function AS_FlexContainer_b3d65338f6d64b66ab479766ee04c24a(eventobject, x, y) {
    function SCALE_ACTION____ac5e5603d31042fca170d72c179a32cf_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "width": "40%",
            "height": "40%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____ac5e5603d31042fca170d72c179a32cf_Callback
    });
}

function AS_FlexContainer_b586ec0339f541eb8f324eb1485bbcc2(eventobject, x, y) {
    function SCALE_ACTION____cc540b9bd019430cbafe8ab48d071fbf_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "width": "70%",
            "rectified": true,
            "height": "70%"
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____cc540b9bd019430cbafe8ab48d071fbf_Callback
    });
}

function AS_FlexContainer_cfed6dbf3d024067815e93a08b212ed4(eventobject, x, y) {
    function SCALE_ACTION____c97eac49d0bd4e2d93f98770e95e36d9_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "maxHeight": "120%",
            "maxWidth": "120%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____c97eac49d0bd4e2d93f98770e95e36d9_Callback
    });
}

function AS_FlexScrollContainer_b95a96d9acd6411a99b32b478b0492f5(eventobject, x, y) {
    frmGroups.flxScroller["isVisible"] = false;
}

function AS_Form_a8f2eee4342b43aa86bb123b3d480ec9(eventobject) {
    return form_IntStart.call(this);
}

function AS_Form_b68bd7768f874a96b4c5937cb01763b5(eventobject) {
    return frmGroups_init.call(this);
}

function AS_Form_ba9afd4cb19849b0bde1211ca0dd96dd(eventobject) {
    return editProfile_init.call(this);
}

function AS_Form_bdc1409a0859409db5283872b12399f6(eventobject) {
    return form_Int.call(this);
}

function AS_Form_c00d71e946024baa83a6b29ae9fe2cf9(eventobject) {}

function AS_Form_d15de87c8c6f42cbb4bed10f9c9e0d35(eventobject) {
    return groupDetails_init.call(this);
}

function AS_Form_he9cc1789e194c3b82f90fefb54717a2(eventobject) {
    return form_Inttemp.call(this);
}

function AS_Form_hf00cf381ee141fbb1b5d5d63312e648(eventobject) {}

function AS_Form_i84459361419498e81f25186a0d12993(eventobject) {}

function AS_Image_f02a5ba3086f40d291a83798041409e1(eventobject, x, y) {}

function AS_Image_i11e3948b51144abb7a34088bd63a235(eventobject, x, y) {
    function SCALE_ACTION____dfd7f3aa037b43ba81322aac372bcfbd_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "maxHeight": "120%",
            "maxWidth": "120%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____dfd7f3aa037b43ba81322aac372bcfbd_Callback
    });
}

function AS_Popup_h65dbd23ca944fd28eba00e549f021ce(eventobject) {
    return popNo_init.call(this);
}

function AS_Popup_i2f6d0bd52914c8697dbc5630ef44816(eventobject) {
    return popConfirmDelete_init.call(this);
}

function AS_VBox_ed54d7112c934623b361d314ce9a4004(eventobject) {
    return popNo_init.call(this);
}