function addWidgetsfrmTemp() {
    frmTemp.setDefaultUnit(kony.flex.DP);
    var flxBuckets = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxBuckets",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0d710c892040646",
        "top": "0dp",
        "width": "100%",
        "zIndex": 100
    }, {}, {});
    flxBuckets.setDefaultUnit(kony.flex.DP);
    var flxBucketProspect = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "0%",
        "clipBounds": true,
        "height": "280dp",
        "id": "flxBucketProspect",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    flxBucketProspect.setDefaultUnit(kony.flex.DP);
    var ImgProspect = new kony.ui.Image2({
        "centerY": "64.29%",
        "height": "73dp",
        "id": "ImgProspect",
        "isVisible": true,
        "right": "26.04%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Label0h9f6137078bb41 = new kony.ui.Label({
        "id": "Label0h9f6137078bb41",
        "isVisible": true,
        "left": "151dp",
        "skin": "sknLblBottomText",
        "text": "Prospect",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblProspectNumber = new kony.ui.Label({
        "id": "lblProspectNumber",
        "isVisible": true,
        "left": "166dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "180dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxBucketProspect.add(ImgProspect, Label0h9f6137078bb41, lblProspectNumber);
    var CopyflxBucketProspect0f5102205494548 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "1%",
        "clipBounds": true,
        "height": "280dp",
        "id": "CopyflxBucketProspect0f5102205494548",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "280dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f5102205494548.setDefaultUnit(kony.flex.DP);
    var imgCustomer = new kony.ui.Image2({
        "centerY": "62%",
        "height": "73dp",
        "id": "imgCustomer",
        "isVisible": true,
        "left": "24%",
        "right": "30%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0b7eb7a6af8b444 = new kony.ui.Label({
        "id": "CopyLabel0b7eb7a6af8b444",
        "isVisible": true,
        "left": "52dp",
        "skin": "sknLblBottomText",
        "text": "Customer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "221dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblCustomerNumber = new kony.ui.Label({
        "id": "lblCustomerNumber",
        "isVisible": true,
        "left": "85dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "170dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0f5102205494548.add(imgCustomer, CopyLabel0b7eb7a6af8b444, lblCustomerNumber);
    var CopyflxBucketProspect0f2f6d40304a94f = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "0%",
        "centerY": "100%",
        "clipBounds": true,
        "height": "290dp",
        "id": "CopyflxBucketProspect0f2f6d40304a94f",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0f2f6d40304a94f.setDefaultUnit(kony.flex.DP);
    var imgRegisteredCustomer = new kony.ui.Image2({
        "centerY": "32%",
        "height": "73dp",
        "id": "imgRegisteredCustomer",
        "isVisible": true,
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "12dp",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0j97fad3d02f648 = new kony.ui.Label({
        "id": "CopyLabel0j97fad3d02f648",
        "isVisible": true,
        "left": "145dp",
        "skin": "sknLblBottomText",
        "text": "Reg Customer",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblRegCustNumber = new kony.ui.Label({
        "id": "lblRegCustNumber",
        "isVisible": true,
        "left": "172dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "89dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0f2f6d40304a94f.add(imgRegisteredCustomer, CopyLabel0j97fad3d02f648, lblRegCustNumber);
    var CopyflxBucketProspect0bc4c4a78143f42 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "100%",
        "centerY": "100%",
        "clipBounds": true,
        "height": "290dp",
        "id": "CopyflxBucketProspect0bc4c4a78143f42",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "16dp",
        "skin": "sknFlxPink",
        "top": "40dp",
        "width": "290dp",
        "zIndex": 1
    }, {}, {});
    CopyflxBucketProspect0bc4c4a78143f42.setDefaultUnit(kony.flex.DP);
    var imgABO = new kony.ui.Image2({
        "height": "73dp",
        "id": "imgABO",
        "isVisible": true,
        "left": "25%",
        "right": "10%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "19%",
        "width": "20%",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var CopyLabel0fcf13fc0192541 = new kony.ui.Label({
        "id": "CopyLabel0fcf13fc0192541",
        "isVisible": true,
        "left": "83dp",
        "skin": "sknLblBottomText",
        "text": "ABO",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "23dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblABONumber = new kony.ui.Label({
        "id": "lblABONumber",
        "isVisible": true,
        "left": "93dp",
        "skin": "CopysknLblBottomText0edfd0691eb104a",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "90dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    CopyflxBucketProspect0bc4c4a78143f42.add(imgABO, CopyLabel0fcf13fc0192541, lblABONumber);
    var flexAnim = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "125dp",
        "id": "flexAnim",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "110dp",
        "skin": "CopyflxSkn0aad307a0e5dc47",
        "top": "230dp",
        "width": "125dp",
        "zIndex": 200
    }, {}, {});
    flexAnim.setDefaultUnit(kony.flex.DP);
    var Label0cff5775dbf1e4a = new kony.ui.Label({
        "centerY": "50%",
        "height": "100%",
        "id": "Label0cff5775dbf1e4a",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0a4a289f7d8c74e",
        "text": "Drag to any group or move sideways to add to a custom group ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "22dp",
        "width": "98%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flexAnim.add(Label0cff5775dbf1e4a);
    flxBuckets.add(flxBucketProspect, CopyflxBucketProspect0f5102205494548, CopyflxBucketProspect0f2f6d40304a94f, CopyflxBucketProspect0bc4c4a78143f42, flexAnim);
    frmTemp.add(flxBuckets);
};

function frmTempGlobals() {
    frmTemp = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmTemp,
        "bounces": false,
        "enableScrolling": false,
        "enabledForIdleTimeout": false,
        "id": "frmTemp",
        "init": AS_Form_he9cc1789e194c3b82f90fefb54717a2,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "pagingEnabled": false,
        "skin": "CopyslForm0bbe3563ab5ed43"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};