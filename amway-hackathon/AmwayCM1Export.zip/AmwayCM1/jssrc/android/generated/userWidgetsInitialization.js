function initializeUserWidgets() {
    kony.mvc.registry.add("com.org.amway.logo", "logo", "logoController");
    kony.application.registerMaster({
        "namespace": "com.org.amway",
        "classname": "logo",
        "name": "com.org.amway.logo"
    });
    kony.mvc.registry.add("com.org.amwayLogo.logo", "logo", "logoController");
    kony.application.registerMaster({
        "namespace": "com.org.amwayLogo",
        "classname": "logo",
        "name": "com.org.amwayLogo.logo"
    });
}