function addWidgetspopNoCustomGroups() {
    var HBox0jc5efcfa74bd4c = new kony.ui.Box({
        "id": "HBox0jc5efcfa74bd4c",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slHbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var VBox0f984a250796c4c = new kony.ui.Box({
        "id": "VBox0f984a250796c4c",
        "isVisible": true,
        "onClick": AS_VBox_ed54d7112c934623b361d314ce9a4004,
        "orientation": constants.BOX_LAYOUT_VERTICAL,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "skin": "slVbox"
    }, {
        "containerWeight": 100,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var Label0a7f56e5a41ba45 = new kony.ui.Label({
        "id": "Label0a7f56e5a41ba45",
        "isVisible": true,
        "skin": "CopyslLabel0fc29375c375a41",
        "text": "Sorry it seems you dont have any custom groups",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        }
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": false,
        "padding": [0, 6, 0, 6],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var btnYes = new kony.ui.Button({
        "focusSkin": "CopyslButtonGlossBlue0bdffa29cab0c41",
        "id": "btnYes",
        "isVisible": true,
        "skin": "CopyslButtonGlossBlue0e96a1ee51ede40",
        "text": "Yes"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [2, 6, 2, 6],
        "marginInPixel": false,
        "padding": [2, 4, 2, 4],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    VBox0f984a250796c4c.add(Label0a7f56e5a41ba45, btnYes);
    HBox0jc5efcfa74bd4c.add(VBox0f984a250796c4c);
    popNoCustomGroups.add(HBox0jc5efcfa74bd4c);
};

function popNoCustomGroupsGlobals() {
    popNoCustomGroups = new kony.ui.Popup({
        "addWidgets": addWidgetspopNoCustomGroups,
        "id": "popNoCustomGroups",
        "init": AS_Popup_h65dbd23ca944fd28eba00e549f021ce,
        "isModal": false,
        "skin": "CopyslPopup0j59ca1535ec64d",
        "transparencyBehindThePopup": 50
    }, {
        "containerWeight": 80,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "windowSoftInputMode": constants.POPUP_ADJUST_PAN
    });
};