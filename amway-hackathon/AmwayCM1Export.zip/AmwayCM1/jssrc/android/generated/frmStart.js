function addWidgetsfrmStart() {
    frmStart.setDefaultUnit(kony.flex.DP);
    var flxParent = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "bottom": "4%",
        "clipBounds": true,
        "height": "15%",
        "id": "flxParent",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_HORIZONTAL,
        "left": "0dp",
        "skin": "CopyslFbox0ga0f0215f1c647",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxParent.setDefaultUnit(kony.flex.DP);
    var flxGroup1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0fd3fa20827df4c",
        "height": "100%",
        "id": "flxGroup1",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "25%",
        "zIndex": 1
    }, {}, {});
    flxGroup1.setDefaultUnit(kony.flex.DP);
    var ImgProspect = new kony.ui.Image2({
        "centerX": "50%",
        "height": "55%",
        "id": "ImgProspect",
        "isVisible": true,
        "left": "20%",
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "5%",
        "width": "70%",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNum1 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblNum1",
        "isVisible": true,
        "left": "39dp",
        "skin": "CopyslLabel0b0778305317344",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "24dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblGrpName1 = new kony.ui.Label({
        "id": "lblGrpName1",
        "isVisible": true,
        "left": "0%",
        "skin": "CopysknLblBottomText0f33573d73cfa40",
        "text": "custom Group ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "60%",
        "width": "100%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGroup1.add(ImgProspect, lblNum1, lblGrpName1);
    var flxGroup2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0fd3fa20827df4c",
        "height": "100%",
        "id": "flxGroup2",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "25%",
        "zIndex": 1
    }, {}, {});
    flxGroup2.setDefaultUnit(kony.flex.DP);
    var lblNum2ssdsd = new kony.ui.Image2({
        "centerX": "50%",
        "height": "55%",
        "id": "lblNum2ssdsd",
        "isVisible": true,
        "left": "20%",
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "5%",
        "width": "70%",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNum2 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblNum2",
        "isVisible": true,
        "left": "39dp",
        "skin": "CopyslLabel0b0778305317344",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "24dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblGrpName2 = new kony.ui.Label({
        "id": "lblGrpName2",
        "isVisible": true,
        "left": "0%",
        "skin": "CopysknLblBottomText0f33573d73cfa40",
        "text": "custom Group ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "60%",
        "width": "100%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGroup2.add(lblNum2ssdsd, lblNum2, lblGrpName2);
    var flxGroup3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0fd3fa20827df4c",
        "height": "100%",
        "id": "flxGroup3",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "25%",
        "zIndex": 1
    }, {}, {});
    flxGroup3.setDefaultUnit(kony.flex.DP);
    var CopyImgProspect0a095f03bf63246 = new kony.ui.Image2({
        "centerX": "50%",
        "height": "55%",
        "id": "CopyImgProspect0a095f03bf63246",
        "isVisible": true,
        "left": "20%",
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "5%",
        "width": "70%",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNum3 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblNum3",
        "isVisible": true,
        "left": "39dp",
        "skin": "CopyslLabel0b0778305317344",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "24dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblGrpName3 = new kony.ui.Label({
        "id": "lblGrpName3",
        "isVisible": true,
        "left": "0%",
        "skin": "CopysknLblBottomText0f33573d73cfa40",
        "text": "custom Group ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "60%",
        "width": "100%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGroup3.add(CopyImgProspect0a095f03bf63246, lblNum3, lblGrpName3);
    var flxGroup4 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "focusSkin": "CopyslFbox0fd3fa20827df4c",
        "height": "100%",
        "id": "flxGroup4",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "25%",
        "zIndex": 1
    }, {}, {});
    flxGroup4.setDefaultUnit(kony.flex.DP);
    var CopyImgProspect0b5aaef66d56c45 = new kony.ui.Image2({
        "centerX": "50%",
        "height": "55%",
        "id": "CopyImgProspect0b5aaef66d56c45",
        "isVisible": true,
        "left": "20%",
        "right": "26%",
        "skin": "slImage",
        "src": "pshape.png",
        "top": "5%",
        "width": "70%",
        "zIndex": 5
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblNum4 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "40%",
        "id": "lblNum4",
        "isVisible": true,
        "left": "39dp",
        "skin": "CopyslLabel0b0778305317344",
        "text": "75",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "24dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblGrpName4 = new kony.ui.Label({
        "id": "lblGrpName4",
        "isVisible": true,
        "left": "0%",
        "skin": "CopysknLblBottomText0f33573d73cfa40",
        "text": "custom Group ",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "60%",
        "width": "100%",
        "zIndex": 5
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    flxGroup4.add(CopyImgProspect0b5aaef66d56c45, lblNum4, lblGrpName4);
    flxParent.add(flxGroup1, flxGroup2, flxGroup3, flxGroup4);
    var lblNote = new kony.ui.Label({
        "bottom": "0%",
        "height": "4%",
        "id": "lblNote",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel0d10349fed59940",
        "text": "Note: Press the custom group to add the contact",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "width": "98%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    frmStart.add(flxParent, lblNote);
};

function frmStartGlobals() {
    frmStart = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmStart,
        "enabledForIdleTimeout": false,
        "id": "frmStart",
        "init": AS_Form_a8f2eee4342b43aa86bb123b3d480ec9,
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "CopyslForm0bbe3563ab5ed43"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_PAN
    });
};