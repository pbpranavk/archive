//Type your code here
function frmStart_init() {
    // frmStart.preShow = frmStart_preshow;
    frmStart.postShow = frmHome_postShow;
}
var TempArray = [];

function frmStart_preshow() {
    var SegData = {
        "Array": [{
            "name": "Sreeteja"
        }, {
            "name": "Pranav"
        }, {
            "name": "Asrihta"
        }, {
            "name": "Harsha"
        }, {
            "name": "Savanth"
        }]
    };
    var Array = SegData["Array"];
    var j = 0;
    kony.print("Savanth ---> String is " + JSON.stringify(Array));
    for (var i = 0; i < (Array.length) / 2; i++) {
        if (j + 1 <= Array.length - 1) {
            kony.print("Savanth ---> Inside Even");
            TempArray.push({
                lblDummyData1: {
                    text: Array[j]["name"]
                },
                lblDummyData2: {
                    text: Array[j + 1]["name"]
                },
                flxContactDetails1: {
                    "skin": "flxSkn" + randomSkinGene(2, 1)
                },
                flxContactDetails2: {
                    "skin": "flxSkn" + randomSkinGene(2, 1)
                }
            });
        } else {
            kony.print("Savanth ---> Inside Odd");
            TempArray.push({
                lblDummyData1: {
                    text: Array[j]["name"]
                },
                flxContactDetails2: {
                    isVisible: false
                }
            });
        }
        j = j + 2;
    }
    //frmStart.segCOntactDetails.setData(TempArray);
}

function frmHome_postShow() {
    var data = kony.contact.find('*', true);
    kony.print(JSON.stringify(data));
    var nameLogs = [];
    var d = 0;
    for (var i = 0; i < (data.length) / 2; i++) {
        kony.print("Pranav ---> d is" + d);
        kony.print("Harsha ---> data[d] is" + data[d]);
        kony.print("Harsha ---> data[d+1] is" + data[d + 1]);
        if ((data[d].firstname !== undefined) && (data[d + 1].firstname !== undefined))
            if (d + 1 <= data.length - 1) {
                kony.print("Savanth ---> Inside Even");
                TempArray.push({
                    lblDummyData1: {
                        text: splitName(data[d].firstname)
                    },
                    lblDummyData2: {
                        text: splitName(data[d + 1].firstname)
                    },
                    lblShortName1: {
                        text: data[d].firstname
                    },
                    lblShortName2: {
                        text: data[d + 1].firstname
                    },
                    flxContactDetails1: {
                        "skin": "flxSkn" + randomSkinGene(2, 1)
                    },
                    flxContactDetails2: {
                        "skin": "flxSkn" + randomSkinGene(2, 1)
                    }
                });
            } else {
                kony.print("Savanth ---> Inside Odd");
                TempArray.push({
                    lblDummyData1: {
                        text: splitName(data[d].firstname)
                    },
                    lblShortName1: {
                        text: data[d].firstname
                    },
                    flxContactDetails2: {
                        isVisible: false
                    }
                });
            }
        d = d + 2;
    }
    //  kony.print("a "+ data);
    kony.print("After Even");
    //frmStart.segCOntactDetails.setData(TempArray);
    kony.print("After setData");
}

function splitName(s) {
    var res = [];
    res = s.split(" ");
    var fin = "";
    if (res.length > 1) {
        var i = 1;
        for (; i < res.length; i++) {
            if (res[i].charAt(0) !== '') {
                fin = res[0].charAt(0) + "" + res[i].charAt(0).toUpperCase();
                break;
            }
        }
        if (i === res.length) fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    } else {
        fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    }
    return fin;
}
/*
function randomSkinGene(max, min){  
    return Math.floor(Math.random() * (max - min + 1)) + min;  	
} */