//Type your code here
var isFromEdit = false;

function editProfile_init() {
    frmEditProf.preShow = frmEditProf_preShow;
    frmEditProf.postShow = frmEditProf_postShow;
    frmEditProf.onDeviceBack = frmEditProf_btnSave_onClick;
    frmEditProf.btnCall.onClick = frmEditProf_btnCall_onClick;
    frmEditProf.btnMail.onClick = frmEditProf_btnMail_onClick;
    frmEditProf.btnSave.onClick = frmEditProf_btnSave_onClick;
}

function frmEditProf_preShow() {
    //   var name = editArr[0].firstname;
    //   var phone = editArr[0].phone[0].number;   
    // frmEditProf.lblProPic.text = 	splitName(name);
    isFromEdit = false;
}

function frmEditProf_postShow() {}

function frmEditProf_onDeviceBack() {
    var name = frmEditProf.tbxName.text;
    var phone = frmEditProf.tbxPhone.text;
    var email = frmEditProf.tbxEmail.text;
    kony.application.showLoadingScreen();
    var prevForm = kony.application.getPreviousForm().id;
    if (prevForm == "frmDyn") {
        frmDyn.flxAdd.removeAll();
        //    data[flxId].firstname = name;
        //   data[flxId].phone[0].number = phone;
        //   data[flxId]["email"] = email;
        genContacts();
        frmDyn.show();
        editArr = [];
    } else {
        //data1 = [];
        frmGroupDetails.flxContactList.removeAll();
        //   //isFromProspects = false;    
        //   /isFromCustomers = false;
        //   isFromRegCust = false;
        //   isFromAbo = false;
        //frmEditProf.tbxName.text = "";
        //frmEditProf.tbxPhone.text = "";
        //frmEditProf.tbxEmail.text = "";
        isFromEdit = true;
        editArr = [];
        //alert("harsha --> data is "+JSON.stringify(data));
        frmGroupDetails.show();
    }
}

function frmEditProf_btnCall_onClick() {
    callANumber();
}

function callANumber() {
    try {
        var number = gblPhoneNum;
        kony.phone.dial(number);
    } catch (err) {}
}

function frmEditProf_btnSave_onClick() {
    var name = frmEditProf.tbxName.text;
    var phone = frmEditProf.tbxPhone.text;
    var email = frmEditProf.tbxEmail.text;
    var prevForm = kony.application.getPreviousForm().id;
    if (prevForm == "frmDyn") {
        // alert("harsha prevForm is "+prevForm);
        data1[fId].firstname = name;
        data1[fId].phone[0].number = phone;
        data1[fId]["email"] = email;
        frmDyn.flxAdd.removeAll();
        genContacts();
        frmDyn.show();
    } else {
        if (isFromCustomers == true) {
            gblCustArr[flxId].firstname = name;
            gblCustArr[flxId].phone[0].number = phone;
            gblCustArr[flxId]["email"] = email;
        } else if (isFromProspects == true) {
            gblProsArr[flxId].firstname = name;
            gblProsArr[flxId].phone[0].number = phone;
            gblProsArr[flxId]["email"] = email;
        } else if (isFromRegCust == true) {
            gblRegCustArr[flxId].firstname = name;
            gblRegCustArr[flxId].phone[0].number = phone;
            gblRegCustArr[flxId]["email"] = email;
        } else if (isFromAbo == true) {
            gblisAboArr[flxId].firstname = name;
            gblisAboArr[flxId].phone[0].number = phone;
            gblisAboArr[flxId]["email"] = email;
        }
        frmGroupDetails.flxContactList.removeAll();
        kony.application.showLoadingScreen();
        frmGroupDetails.show();
    }
    isFromEdit = true;
    gblEmailId = "";
    editArr = [];
}

function sendEmail() {
    try {
        var eid = frmEditProf.tbxEmail.text;
        if (eid != "" || eid != " " || eid != null || eid != undefined) {
            var to = [eid];
        } else {
            //  alert("please update your email id");
        }
        var cc = [""];
        var bcc = [""];
        var sub = "";
        var msgbody = "";
        kony.phone.openEmail(to, cc, bcc, sub, msgbody, true, []);
    } catch (err) {}
}

function frmEditProf_btnMail_onClick() {
    // alert("harsha --> inside btn mail click");
    sendEmail();
}