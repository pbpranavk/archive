//Type your code here
var data = [];
var data1 = [];
var gblArrayLength = 0;
var count = 1;
var isfirst = true;
var curDest = null;
var curFrom = null;
var gblX = 0;
var gblY = 0;
var gblTileClicked = null;
var gblQuad1 = {}
var gblQuad2 = {}
var gblQuad3 = {}
var gblQuad4 = {}
gblQuad1["x"] = 70;
gblQuad1["y"] = 70;
gblQuad2["x"] = 341 //1010;
gblQuad2["y"] = 70;
gblQuad3["x"] = 70;
gblQuad3["y"] = 636; //1850;
gblQuad4["x"] = 341; //1010;
gblQuad4["y"] = 636;
var formHeight = 1980;
var formWidth = 1080;
var gblWhichQuad = 0;

function form_Int() {
    //frmTemp.destroy();
    //sfrmStart.destroy();
    data = kony.store.getItem("data");
    data1 = data;
    if (data == null || data == undefined || data == "") {
        getData();
    }
    genContacts();
    //frmDyn.postShow = genContacts;
    // frmDyn.FlexContainer0b2838e17d3c546.onTouchMove = touchMove;
    frmDyn.btnGroups.onClick = frmDyn_btnContacts_onClick;
    frmDyn.preShow = frmDyn_preShow;
    frmDyn.flxAdd.showFadingEdges = false;
}

function frmDyn_preShow() {
    data = kony.store.getItem("data");
}

function retrieveDataFromDB() {
    gblCustArr = kony.store.getItem("gblCustArr");
    if (gblCustArr == null || gblCustArr == undefined || gblCustArr == "") {
        kony.print("Savanth --> Inside Here" + gblCustArr);
        gblCustArr = [];
    }
    gblProsArr = kony.store.getItem("gblProsArr");
    if (gblProsArr == null || gblProsArr == undefined || gblProsArr == "") {
        gblProsArr = [];
    }
    gblRegCustArr = kony.store.getItem("gblRegCustArr");
    if (gblRegCustArr == null || gblRegCustArr == undefined || gblRegCustArr == "") {
        gblRegCustArr = [];
    }
    gblisAboArr = kony.store.getItem("gblisAboArr");
    if (gblisAboArr == null || gblisAboArr == undefined || gblisAboArr == "") {
        gblisAboArr = [];
    }
}

function form_Inttemp() {
    //frmTemp.flexAnim.onTouchStart = dragStart;
    //frmTemp.flexAnim.onTouchMove = dradDrop;
    // frmTemp.flexAnim.onTouchEnd = endAction;
    frmTemp.preShow = frmTemp_preShow;
    frmTemp.flexAnim.top = 250;
    frmTemp.flexAnim.left = 130;
    frmTemp.lblProspectNumber.setVisibility(true);
    //frmDyn.flxAdd.showFadingEdges = false;
    var DeviceDetails = kony.os.deviceInfo();
    kony.print("Savanth ---> Device Height " + DeviceDetails["screenHeight"]);
    kony.print("Savanth ---> Device Width " + DeviceDetails["screenWidth"]);
    formHeight = DeviceDetails["screenHeight"] - 70;
    formWidth = DeviceDetails["screenWidth"] - 70;
    gblQuad2["x"] = formWidth;
    gblQuad3["y"] = formHeight;
    gblQuad4["x"] = formWidth;
    gblQuad4["y"] = formHeight;
}

function frmTemp_preShow() {
    var Tempflex = gblTileClicked.clone();
    kony.print("Savanth ---> widget " + JSON.stringify(gblTileClicked));
    kony.print("Savanth ---> widget " + JSON.stringify(Tempflex));
    Tempflex["top"] = 250;
    Tempflex["left"] = 130;
    Tempflex["height"] = 125;
    Tempflex["width"] = 125;
    Tempflex["onTouchStart"] = dragStart;
    Tempflex["onTouchMove"] = dradDrop;
    Tempflex["onTouchEnd"] = endAction;
    gblSkinForAnim = Tempflex["skin"];
    frmTemp.flexAnim.setVisibility(true);
    frmTemp.flxBuckets.add(Tempflex);
    frmTemp.lblProspectNumber.text = (gblProsArr.length.toPrecision());
    frmTemp.lblCustomerNumber.text = (gblCustArr.length.toPrecision());
    frmTemp.lblRegCustNumber.text = (gblRegCustArr.length.toPrecision());
    frmTemp.lblABONumber.text = (gblisAboArr.length.toPrecision());
    data = kony.store.getItem("data");
}

function getData() {
    data = kony.contact.find('*', true);
    kony.print("pranav data is--->" + JSON.stringify(data));
    if (data.length > 50) {
        data = data.slice(0, 50);
    }
    gblArrayLength = data.length;
    data1 = data;
    kony.store.setItem("data", data);
}

function genContacts() {
    kony.print("Savanth ----> Inside Dynamic Flex Creation");
    var flxContacts = [];
    var flxContactDetails1 = [];
    var lblShortName1 = [];
    var lblDummyData1 = [];
    var btnCancel1 = [];
    var btnEdit1 = [];
    var flxContactDetails2 = [];
    var lblShortName2 = [];
    var lblDummyData2 = [];
    var btnMore2 = [];
    var edit2 = [];
    var j = 0;
    for (var i = 0; i < data1.length / 2; i++) {
        if (j + 1 <= data1.length - 1) {
            if ((data1[j].firstname !== undefined) && (data1[j + 1].firstname !== undefined)) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + j,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails" + j,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName" + j,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data1[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData" + j,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data1[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel" + j,
                    "isVisible": false,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit" + j,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": EditHome,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContactDetails2[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails" + (j + 1),
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "50%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails2[i].setDefaultUnit(kony.flex.DP);
                lblShortName2[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName" + (j + 1),
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data1[j + 1].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData2[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData" + (j + 1),
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data1[j + 1].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnMore2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "height": "15%",
                    "id": "btnMore" + (j + 1),
                    "isVisible": false,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                edit2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "edit" + (j + 1),
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": EditHome,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                kony.print("Savanth ---> adding ");
                flxContactDetails2[i].add(lblShortName2[i], lblDummyData2[i], btnMore2[i], edit2[i]);
                flxContacts[i].add(flxContactDetails1[i], flxContactDetails2[i]);
                try {
                    flxContactDetails1[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    flxContactDetails2[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    kony.print("pranav --->Inside try");
                } catch (e) {
                    kony.print("Error" + e);
                }
                frmDyn.flxAdd.add(flxContacts[i]);
                kony.print("Savanth --->After  adding ");
            }
        } else {
            kony.print("In odd");
            if (data1[i].firstname !== undefined) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails1" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(10, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName1" + i,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data1[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData1" + i,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data1[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel1" + i,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit1" + i,
                    "isVisible": true,
                    "left": "5%",
                    "right": -3,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": EditHome,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContacts[i].add(flxContactDetails1[i]);
                try {
                    flxContactDetails1[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    //flxContactDetails2[i].setGestureRecognizer(3, {pressDuration:2}, onGestureCallback);
                    kony.print("pranav --->Inside try");
                } catch (e) {
                    kony.print("Error" + e);
                }
                frmDyn.flxAdd.add(flxContacts[i]);
            }
        }
        j = j + 2;
    }
}

function splitName(s) {
    var res = [];
    res = s.split(" ");
    var fin = "";
    if (res.length > 1) {
        var i = 1;
        for (; i < res.length; i++) {
            if (res[i].charAt(0) !== '') {
                fin = res[0].charAt(0) + "" + res[i].charAt(0).toUpperCase();
                break;
            }
        }
        if (i === res.length) fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    } else {
        fin = res[0].charAt(0) + "" + res[0].charAt(1).toUpperCase();
        //alert(fin);
    }
    return fin;
}
var color1 = 1;
var color2 = 0;

function randomSkinGene(max, min) {
    if (color1 == 1) {
        color1 = 2;
        return min;
    }
    if (color1 == 2) {
        color1 = 0;
        color2 = 1;
        return max;
    }
    if (color2 == 1) {
        color2 = 2;
        return max;
    }
    if (color2 == 2) {
        color2 = 0;
        color1 = 1;
        return min;
    }
}

function onGestureCallback(commonWidget, gestureInfo) // The callback function when the gesture event is triggered.
{
    //alert(gestureInfo);
    //alert(commonWidget.id);
    gblTileClicked = commonWidget;
    try {
        var GesType = "" + gestureInfo.gestureType;
        if (GesType == "3") {
            frmTemp.show();
            //kony.print("savanth ----> Inside Gesture Recognizer");
            //kony.print("Savanth ---> Flex is " + commonWidget.id);
            //frmGestures.lblGesture.text = "A longpress gesture was performed";
            //rmGestures.imgGes.src = "longpress.png"; 
        }
    } catch (err) {
        //alert("error in gesture call back"+err);
    }
}

function touchMove(source, x, y) {
    if (source.left >= 0) {
        source.left += parseInt(x) - 5;
    }
    if (source.left < 0) {
        source.left = 0;
    }
    //  if(source.left > frmDyn.FlexContainer0b2838e17d3c546.width){
    //  source.left = frmDyn.FlexContainer0b2838e17d3c546.width;
    //}  
    frmDyn.FlexContainer0b2838e17d3c546.forceLayout();
}

function dragStart(source, x, y) {
    kony.print("Savanth ---> Started Dragging");
    frmTemp.flexAnim.setVisibility(false);
    gblX = x;
    gblY = y;
}

function dradDrop(source, x, y) {
    kony.print("savanth ---> X : " + x + " Y " + y);
    var dx = x - gblX;
    var dy = y - gblY;
    var leftX = source.left + dx;
    var topY = source.top + dy;
    kony.print("Savanth Calc Value = " + leftX)
    if (leftX <= gblQuad1["x"] && topY <= gblQuad1["y"] || ((leftX + 125) >= gblQuad2["x"]) && topY <= gblQuad2["y"] || leftX <= gblQuad3["x"] && (topY + 125) >= gblQuad3["y"] || (leftX + 125) >= gblQuad4["x"] && (topY + 125) >= gblQuad4["y"]) {
        kony.print("Savanth ---> Inside some quad");
        source.skin = sknPink1;
    } else if (leftX < 0 || (leftX + 125) > (formWidth + 70)) {
        gblWhichQuad = 5;
        source.skin = skngrey1;
    } else {
        source.skin = gblSkinForAnim;
    }
    if (leftX <= gblQuad1["x"] && topY <= gblQuad1["y"]) {
        gblWhichQuad = 1;
    } else if ((leftX + 125) >= gblQuad2["x"] && topY <= gblQuad2["y"]) {
        gblWhichQuad = 2;
    } else if (leftX <= gblQuad3["x"] && (topY + 125) >= gblQuad3["y"]) {
        gblWhichQuad = 3;
    } else if ((leftX + 125) >= gblQuad4["x"] && (topY + 125) >= gblQuad4["y"]) {
        gblWhichQuad = 4;
    } else if (leftX < 0 || (leftX + 125) > (formWidth + 70)) {
        gblWhichQuad = 5;
    } else {
        gblWhichQuad = 0;
    }
    source.left += dx;
    source.top += dy;
    kony.print("savanth ---> top " + source.top);
    kony.print("Savanth ---> dy " + dy);
    frmTemp.flxBuckets.forceLayout();
}

function endAction(source, x, y) {
    var id;
    kony.print("Savanth ---> source is ", source.id);
    source.skin = gblSkinForAnim;
    switch (gblWhichQuad) {
        case 1:
            id = getId(source);
            gblProsArr.push(data1[id]);
            kony.store.setItem("gblCustArr", gblCustArr);
            isFromProspects = true;
            showContactDetails(gblProsArr, "Prospects");
            frmTemp.lblProspectNumber.text = gblProsArr.length.toPrecision();
            scaleAnim(source, 40, 43);
            break;
        case 2:
            id = getId(source);
            gblCustArr.push(data1[id]);
            kony.store.setItem("gblCustArr", gblCustArr);
            isFromCustomers = true;
            showContactDetails(gblCustArr, "Customers");
            frmTemp.lblCustomerNumber.text = gblCustArr.length.toPrecision();
            scaleAnim(source, gblQuad2["x"], gblQuad2["y"]);
            break;
        case 3:
            id = getId(source);
            gblRegCustArr.push(data1[id]);
            kony.store.setItem("gblRegCustArr", gblRegCustArr);
            isFromRegCust = true;
            showContactDetails(gblRegCustArr, "Registered Customers");
            frmTemp.lblRegCustNumber.text = gblRegCustArr.length.toPrecision();
            scaleAnim(source, gblQuad3["x"], gblQuad3["y"]);
            break;
        case 4:
            id = getId(source);
            gblisAboArr.push(data1[id]);
            kony.store.setItem("gblisAboArr", gblisAboArr);
            isFromAbo = true;
            showContactDetails(gblisAboArr, "ABO");
            frmTemp.lblABONumber.text = gblisAboArr.length.toPrecision();
            scaleAnim(source, gblQuad4["x"], gblQuad4["y"]);
            break;
        case 5:
            if (hasCustomGroups()) {
                frmStart.show();
            } else {
                resetTile(source);
                popNoCustomGroups.show();
            }
            break;
        default:
            return;
    }
}

function hasCustomGroups() {
    if (gblCustomGroupNames.length == 0) {
        return false;
    } else return true;
}

function resetTile(source) {
    source["top"] = 250;
    source["left"] = 130;
    frmTemp.flexAnim.setVisibility(true);
}

function getId(source) {
    var id = source.id;
    var indOs = id.indexOf("s");
    var flxId = id.substring(indOs + 1);
    return flxId;
}

function scaleAnim(source, x, y) {
    var transformRotate = kony.ui.makeAffineTransform();
    var transformScale = kony.ui.makeAffineTransform();
    var transformTranslate = kony.ui.makeAffineTransform();
    transformScale.scale(0, 0);
    transformRotate.rotate(90);
    //transformTranslate
    source.animate(kony.ui.createAnimation({
        0: {
            transform: transformRotate,
        },
        100: {
            top: y,
            left: x,
            transform: transformScale,
        }
    }), {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    }, {
        animationEnd: function() {
            frmTemp.remove(source);
            //frmDyn.show();
            frmGroupDetails.show();
        }
    });
}

function frmDyn_btnContacts_onClick() {
    frmGroups.show();
}

function popNo_init() {
    popNoCustomGroups.btnYes.onClick = dismissPopNo;
}

function dismissPopNo() {
    popNoCustomGroups.dismiss();
}

function EditHome(source) {
    var id = source.id;
    var indOs = id.indexOf("i");
    fId = id.substring(indOs + 2);
    editArr.push(data1[fId]);
    name = editArr[0].firstname;
    phone = editArr[0].phone[0].number;
    gblPhoneNum = phone;
    if (editArr[0]["email"] != undefined || editArr[0]["email"] != null) {
        gblEmailId = editArr[0]["email"];
    }
    frmEditProf.tbxName.text = name;
    frmEditProf.tbxPhone.text = phone;
    if (gblEmailId != null || gblEmailId != undefined) {
        frmEditProf.tbxEmail.text = gblEmailId;
    }
    frmEditProf.lblProPic.text = splitName(name);
    frmEditProf.show();
}