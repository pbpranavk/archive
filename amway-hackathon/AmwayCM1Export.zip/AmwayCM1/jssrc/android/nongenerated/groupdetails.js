//Type your code here
var gblArrayLength = 0;
var data = [];
var count = 1;
var data1 = [];
var gblCustArr = [];
var gblProsArr = [];
var gblRegCustArr = [];
var gblisAboArr = [];
var gblPhoneNum = "";
var gblEmailId = "";
var gblEmailList = [];

function groupDetails_init() {
    frmGroupDetails.preShow = frmGroupDetails_preShow;
    frmGroupDetails.postShow = frmGroupDetails_postShow;
    frmGroupDetails.btnProsMore.onClick = frmGroupDetails_btnProsMore_onClick;
    frmGroupDetails.onDeviceBack = frmGroupDetails_onDeviceBack;
    frmGroupDetails.btnAddPeople.onClick = frmGroupDetails_btnAddPeople_onClick;
}

function frmGroupDetails_btnProsMore_onClick() {
    if (frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible == true) {
        frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = false;
    } else {
        frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = true;
    }
}

function frmGroupDetails_preShow() {
    frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = false;
    frmGroupDetails.flxContactList.showFadingEdges = false;
    //getContactData();
    genDetailsContacts();
}

function frmGroupDetails_postShow() {
    kony.application.dismissLoadingScreen();
}

function getContactData() {
    data = [];
    data1 = kony.contact.find('*', true);
    if (isFromProspects == true) {
        if (isFromEdit == false) {
            //gblProsArr = data1.slice(1,12);
            data = gblProsArr;
        } else {
            data = gblProsArr;
        }
        //isFromProspects = false;    
        frmGroupDetails.lblGroupName.text = "Prospects";
    } else if (isFromCustomers == true) {
        if (isFromEdit == false) {
            //gblCustArr = data1.slice(13,24);
            data = gblCustArr;
        } else {
            data = gblCustArr;
        }
        //isFromCustomers = false;
        frmGroupDetails.lblGroupName.text = "Customers";
        kony.print("harsha10 --> data array is given as " + JSON.stringify(gblCustArr));
    } else if (isFromRegCust == true) {
        if (isFromEdit == false) {
            //gblRegCustArr = data1.slice(25,37);
            data = gblRegCustArr;
        } else {
            data = gblRegCustArr;
        }
        // isFromRegCust = false;
        frmGroupDetails.lblGroupName.text = "Registered Customers";
    } else if (isFromAbo == true) {
        if (isFromEdit == false) {
            //gblisAboArr = data1.slice(38,50);
            data = gblisAboArr;
        } else {
            data = gblisAboArr;
        }
        // isFromAbo = false;
        frmGroupDetails.lblGroupName.text = "Might be an ABO";
    }
    gblArrayLength = data.length;
    kony.print("pranav --> gblArrayLength" + gblArrayLength);
}

function genDetailsContacts() {
    kony.print("Savanth ----> Inside Dynamic Flex Creation");
    var flxContacts = [];
    var flxContactDetails1 = [];
    var lblShortName1 = [];
    var lblDummyData1 = [];
    var btnCancel1 = [];
    var btnEdit1 = [];
    var flxContactDetails2 = [];
    var lblShortName2 = [];
    var lblDummyData2 = [];
    var btnMore2 = [];
    var edit2 = [];
    var j = 0;
    for (var i = 0; i < data.length / 2; i++) {
        if (data == null || data == undefined) {
            kony.print("Nothing Here");
            return;
        }
        if (j + 1 <= data.length - 1) {
            kony.print(JSON.stringify(data));
            if ((data[j].firstname !== undefined) && (data[j + 1].firstname !== undefined)) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + j,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails" + j,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(2, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName" + j,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData" + j,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel" + j,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit" + j,
                    "isVisible": true,
                    "left": "5%",
                    "right": -3,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": showEditProfile,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContactDetails2[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails" + (j + 1),
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(2, 1),
                    "top": "2%",
                    "width": "50%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails2[i].setDefaultUnit(kony.flex.DP);
                lblShortName2[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName" + (j + 1),
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j + 1].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData2[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData" + (j + 1),
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j + 1].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnMore2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "height": "15%",
                    "id": "btnMore" + (j + 1),
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0a90686d42b7541",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                edit2[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "edit" + (j + 1),
                    "isVisible": true,
                    "left": "9%",
                    "right": 0,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": showEditProfile,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                kony.print("Savanth ---> adding ");
                flxContactDetails2[i].add(lblShortName2[i], lblDummyData2[i], btnMore2[i], edit2[i]);
                flxContacts[i].add(flxContactDetails1[i], flxContactDetails2[i]);
                kony.print("added stuff --> " + JSON.stringify(flxContacts[i]));
                frmGroupDetails.flxContactList.add(flxContacts[i]);
                try {
                    flxContactDetails1[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    flxContactDetails2[i].setGestureRecognizer(3, {
                        pressDuration: 2
                    }, onGestureCallback);
                    kony.print("pranav --->Inside try");
                } catch (e) {
                    kony.print("Error" + e);
                }
                kony.print("Savanth --->After  adding ");
            }
        } else {
            kony.print("Inside Odd");
            if (data[j].firstname !== undefined) {
                flxContacts[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "20%",
                    "id": "flxParent" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FLOW_HORIZONTAL,
                    "skin": "CopyslFbox0b497ce58c87643"
                }, {}, {});
                flxContacts[i].setDefaultUnit(kony.flex.DP);
                flxContactDetails1[i] = new kony.ui.FlexContainer({
                    "autogrowMode": kony.flex.AUTOGROW_NONE,
                    "clipBounds": true,
                    "height": "100%",
                    "id": "flxContactDetails1" + i,
                    "isVisible": true,
                    "layoutType": kony.flex.FREE_FORM,
                    "left": "1%",
                    "skin": "flxSkn" + randomSkinGene(2, 1),
                    "top": "2%",
                    "width": "47%",
                    "zIndex": 1
                }, {}, {});
                flxContactDetails1[i].setDefaultUnit(kony.flex.DP);
                lblShortName1[i] = new kony.ui.Label({
                    "top": "60%",
                    "centerX": "50%",
                    "id": "lblShortName1" + i,
                    "isVisible": true,
                    "left": "30%",
                    "skin": "CopyslLabel0fd1a2355e6fb4d",
                    "text": data[j].firstname,
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "width": "90%",
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                lblDummyData1[i] = new kony.ui.Label({
                    "centerX": "50%",
                    "centerY": "40%",
                    "id": "lblDummyData1" + i,
                    "isVisible": true,
                    "left": "44dp",
                    "skin": "CopyslLabel0b98410a6393644",
                    "text": splitName(data[j].firstname),
                    "textStyle": {
                        "letterSpacing": 0,
                        "strikeThrough": false
                    },
                    "top": "23dp",
                    "width": kony.flex.USE_PREFFERED_SIZE,
                    "zIndex": 1
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {
                    "textCopyable": false
                });
                btnCancel1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "height": "15%",
                    "id": "btnCancel1" + i,
                    "isVisible": true,
                    "right": "7%",
                    "skin": "CopyslButtonGlossBlue0h39742e7dce949",
                    "onClick": deleteContact,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                btnEdit1[i] = new kony.ui.Button({
                    "focusSkin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "height": "15%",
                    "id": "btnEdit1" + i,
                    "isVisible": true,
                    "left": "5%",
                    "right": -3,
                    "skin": "CopyslButtonGlossBlue0b46bc323ffc94d",
                    "onClick": showEditProfile,
                    "top": "10%",
                    "width": "9%",
                    "zIndex": 5
                }, {
                    "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                    "displayText": true,
                    "padding": [0, 0, 0, 0],
                    "paddingInPixel": false
                }, {});
                flxContactDetails1[i].add(lblShortName1[i], lblDummyData1[i], btnCancel1[i], btnEdit1[i]);
                flxContacts[i].add(flxContactDetails1[i]);
                frmGroupDetails.flxContactList.add(flxContacts[i]);
            }
        }
        j = j + 2;
    }
    //populateContacts();
}
/* function splitName(s){
	var res = [];
	 res= s.split(" ");
	var fin = "";
	if(res.length>1){
		var i = 1;
		for(;i<res.length;i++){
			if(res[i].charAt(0) !== ''){
				fin = res[0].charAt(0)+""+res[i].charAt(0).toUpperCase();
				break;}}
			if(i === res.length)
				fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
			//alert(fin);
	}else{
		fin = res[0].charAt(0)+""+res[0].charAt(1).toUpperCase();
		//alert(fin);
	}
  return fin;
} */
/*
function randomSkinGene(max, min){  
  if(count===10){
    count=1;
    return 10;
  }
  else{
    var p =count;
    count++;
    return p;
  }
  //return Math.floor(Math.random() * (max - min + 1)) + min;  	
} */
function frmGroupDetails_onDeviceBack() {
    data = [];
    frmGroupDetails.flxContactList.removeAll();
    isFromProspects = false;
    isFromCustomers = false;
    isFromRegCust = false;
    isFromAbo = false;
    kony.application.showLoadingScreen();
    frmGroups.show();
}
var flxId = 0;

function deleteContact(source) {
    //alert(source.id);
    var id = source.id;
    var idL = parseInt(id.charAt(id.length - 1));
    var idO = parseInt(id.charAt(id.length - 2));
    idL = idL + 1;
    var mTwo = idL * 2;
    if (idO === 1) flxId = mTwo - 2;
    else flxId = mTwo - 1;
    //alert("value of flxID "+flxId);
    kony.print("gblCustArr is given as " + JSON.stringify(gblCustArr));
    kony.print("splice before odd length " + gblCustArr.length);
    popConfirmDelete.show();
}
//prospect handling for delete
function popup_callback() {
    if (isFromProspects == true) {
        kony.print("harsha --> inside prospects");
        gblProsArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblProsArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblProsArr;
        kony.print("splice before odd length data length is " + data.length);
        genDetailsContacts();
    }
    //customer handling for delete  
    else if (isFromCustomers == true) {
        kony.print("harsha --> inside customers");
        gblCustArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblCustArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblCustArr;
        kony.print("splice before odd length data length is " + data.length);
        genDetailsContacts();
    }
    //registered customer handling for delete
    else if (isFromRegCust == true) {
        kony.print("harsha --> inside registered customers");
        gblRegCustArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblRegCustArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblRegCustArr;
        kony.print("splice before odd length data length is " + data.length);
        genDetailsContacts();
    }
    //Might be an ABO handling for delete  
    else if (isFromAbo == true) {
        kony.print("harsha --> inside abo");
        gblisAboArr.splice(flxId, 1);
        kony.print("splice after odd length " + gblisAboArr.length);
        frmGroupDetails.flxContactList.removeAll();
        data = gblisAboArr;
        kony.print("splice before odd length data length is " + data.length);
        genDetailsContacts();
    }
    popConfirmDelete.dismiss();
}

function accessProperFlex(source) {
    // alert(source);
    kony.print("harsha -->source id of a flex is " + (source.id));
}
var editArr = [];

function showEditProfile(source) {
    // editClicked = true;
    //alert(source);
    kony.print("harsha -->source id of a flex is " + (source.id));
    var id = source.id;
    var idL = parseInt(id.charAt(id.length - 1));
    var idO = parseInt(id.charAt(id.length - 2));
    idL = idL + 1;
    var mTwo = idL * 2;
    if (idO === 1) flxId = mTwo - 2;
    else flxId = mTwo - 1;
    //alert("harsha --> value of flex selected "+flxId);
    var name = "";
    var phone = "";
    if (isFromCustomers == true) {
        editArr.push(gblCustArr[flxId]);
        //alert("harsha --> proper email id is "+gblEmailList[flxId]);
        //alert("populated edit arr is "+JSON.stringify(editArr));
        kony.print("populated edit arr is " + JSON.stringify(editArr));
        name = editArr[0].firstname;
        phone = editArr[0].phone[0].number;
        gblPhoneNum = phone;
        if (editArr[0]["email"] != undefined || editArr[0]["email"] != null) {
            gblEmailId = editArr[0]["email"];
        }
    } else if (isFromProspects == true) {
        editArr.push(gblProsArr[flxId]);
        //alert("harsha --> proper email id is "+gblEmailList[flxId]);
        //alert("populated edit arr is "+JSON.stringify(editArr));
        kony.print("populated edit arr is " + JSON.stringify(editArr));
        name = editArr[0].firstname;
        phone = editArr[0].phone[0].number;
        gblPhoneNum = phone;
        if (editArr[0]["email"] != undefined || editArr[0]["email"] != null) {
            gblEmailId = editArr[0]["email"];
        }
    } else if (isFromRegCust == true) {
        editArr.push(gblRegCustArr[flxId]);
        //alert("harsha --> proper email id is "+gblEmailList[flxId]);
        //alert("populated edit arr is "+JSON.stringify(editArr));
        kony.print("populated edit arr is " + JSON.stringify(editArr));
        name = editArr[0].firstname;
        phone = editArr[0].phone[0].number;
        gblPhoneNum = phone;
        if (editArr[0]["email"] != undefined || editArr[0]["email"] != null) {
            gblEmailId = editArr[0]["email"];
        }
    } else if (isFromAbo == true) {
        editArr.push(gblisAboArr[flxId]);
        //alert("harsha --> proper email id is "+gblEmailList[flxId]);
        //alert("populated edit arr is "+JSON.stringify(editArr));
        kony.print("populated edit arr is " + JSON.stringify(editArr));
        name = editArr[0].firstname;
        phone = editArr[0].phone[0].number;
        gblPhoneNum = phone;
        if (editArr[0]["email"] != undefined || editArr[0]["email"] != null) {
            gblEmailId = editArr[0]["email"];
        }
    }
    frmEditProf.tbxName.text = name;
    frmEditProf.tbxPhone.text = phone;
    if (gblEmailId != null || gblEmailId != undefined) {
        frmEditProf.tbxEmail.text = gblEmailId;
    }
    frmEditProf.lblProPic.text = splitName(name);
    frmEditProf.show();
}

function frmGroupDetails_btnAddPeople_onClick() {
    kony.application.showLoadingScreen();
    frmDyn.show();
    frmGroupDetails.FlexContainer0ed33cd570c734c.isVisible = false;
}

function showContactDetails(tempdata, text) {
    data = tempdata;
    frmGroupDetails.lblGroupName.text = text;
}