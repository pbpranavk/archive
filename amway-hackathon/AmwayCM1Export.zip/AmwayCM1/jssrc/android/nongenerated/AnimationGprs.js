// function bindingEvents(){
//   frmHome.btnGroup.onClick = animGroups;
// }
// function animGroups(){
//   frmHome.flxPros.animate(kony.ui.createAnimation(
//   	{"0" : {"left":"-10%","stepConfig":{"timingFunction":kony.anim.EASIN_IN}},
//     "100" : {"left":"2%","stepConfig":{"timingFunction":kony.anim.EASIN_IN}}}),
//      {"delay":0,"iterationCount":1,"fillMode":kony.anim.FILL_MODE_FORWARDS,"duration":1.0},
//      {"animationEnd":function(){}});
// }