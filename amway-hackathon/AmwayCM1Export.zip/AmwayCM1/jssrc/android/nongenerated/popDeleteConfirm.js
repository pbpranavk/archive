//Type your code here
function popConfirmDelete_init() {
    popConfirmDelete.btnYes.onClick = popConfirmDelete_btnYes;
    popConfirmDelete.btnNo.onClick = popConfirmDelete_btnNo;
    popConfirmDelete.onHide = popConfirmDelete_onHide;
    popConfirmDelete.onDeviceBack = popConfirmDelete_onDeviceBack;
}

function popConfirmDelete_onHide() {
    popConfirmDelete.dismiss();
}

function popConfirmDelete_onDeviceBack() {
    popConfirmDelete.dismiss();
}

function popConfirmDelete_btnYes() {
    popup_callback();
}

function popConfirmDelete_btnNo() {
    popConfirmDelete.dismiss();
}