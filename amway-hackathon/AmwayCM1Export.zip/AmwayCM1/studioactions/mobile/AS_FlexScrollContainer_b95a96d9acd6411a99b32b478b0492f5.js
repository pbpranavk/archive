function AS_FlexScrollContainer_b95a96d9acd6411a99b32b478b0492f5(eventobject, x, y) {
    frmGroups.flxScroller["isVisible"] = false;
}