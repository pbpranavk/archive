function AS_FlexContainer_b3d65338f6d64b66ab479766ee04c24a(eventobject, x, y) {
    function SCALE_ACTION____ac5e5603d31042fca170d72c179a32cf_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "width": "40%",
            "height": "40%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____ac5e5603d31042fca170d72c179a32cf_Callback
    });
}