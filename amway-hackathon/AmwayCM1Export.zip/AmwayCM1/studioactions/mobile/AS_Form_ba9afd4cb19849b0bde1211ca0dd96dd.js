function AS_Form_ba9afd4cb19849b0bde1211ca0dd96dd(eventobject) {
    return editProfile_init.call(this);
}