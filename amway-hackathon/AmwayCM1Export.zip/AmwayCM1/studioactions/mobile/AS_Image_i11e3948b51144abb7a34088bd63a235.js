function AS_Image_i11e3948b51144abb7a34088bd63a235(eventobject, x, y) {
    function SCALE_ACTION____dfd7f3aa037b43ba81322aac372bcfbd_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "maxHeight": "120%",
            "maxWidth": "120%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____dfd7f3aa037b43ba81322aac372bcfbd_Callback
    });
}