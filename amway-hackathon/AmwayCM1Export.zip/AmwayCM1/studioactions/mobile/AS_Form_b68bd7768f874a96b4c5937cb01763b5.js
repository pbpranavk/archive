function AS_Form_b68bd7768f874a96b4c5937cb01763b5(eventobject) {
    return frmGroups_init.call(this);
}