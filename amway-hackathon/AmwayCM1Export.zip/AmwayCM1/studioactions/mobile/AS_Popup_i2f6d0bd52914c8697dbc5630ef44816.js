function AS_Popup_i2f6d0bd52914c8697dbc5630ef44816(eventobject) {
    return popConfirmDelete_init.call(this);
}