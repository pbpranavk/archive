function AS_FlexContainer_cfed6dbf3d024067815e93a08b212ed4(eventobject, x, y) {
    function SCALE_ACTION____c97eac49d0bd4e2d93f98770e95e36d9_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "maxHeight": "120%",
            "maxWidth": "120%",
            "rectified": true
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____c97eac49d0bd4e2d93f98770e95e36d9_Callback
    });
}