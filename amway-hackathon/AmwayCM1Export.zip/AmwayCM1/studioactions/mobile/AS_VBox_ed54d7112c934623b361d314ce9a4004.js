function AS_VBox_ed54d7112c934623b361d314ce9a4004(eventobject) {
    return popNo_init.call(this);
}