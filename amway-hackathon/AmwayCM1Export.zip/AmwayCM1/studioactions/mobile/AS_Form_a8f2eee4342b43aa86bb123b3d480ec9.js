function AS_Form_a8f2eee4342b43aa86bb123b3d480ec9(eventobject) {
    return form_IntStart.call(this);
}