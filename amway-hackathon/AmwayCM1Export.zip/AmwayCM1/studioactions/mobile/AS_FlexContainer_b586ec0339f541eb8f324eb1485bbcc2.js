function AS_FlexContainer_b586ec0339f541eb8f324eb1485bbcc2(eventobject, x, y) {
    function SCALE_ACTION____cc540b9bd019430cbafe8ab48d071fbf_Callback() {}
    undefined.animate(kony.ui.createAnimation({
        "100": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "stepConfig": {
                "timingFunction": kony.anim.EASE
            },
            "width": "70%",
            "rectified": true,
            "height": "70%"
        }
    }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.25
    }, {
        "animationEnd": SCALE_ACTION____cc540b9bd019430cbafe8ab48d071fbf_Callback
    });
}