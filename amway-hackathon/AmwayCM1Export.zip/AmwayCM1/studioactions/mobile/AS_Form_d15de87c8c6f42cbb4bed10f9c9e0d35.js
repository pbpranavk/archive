function AS_Form_d15de87c8c6f42cbb4bed10f9c9e0d35(eventobject) {
    return groupDetails_init.call(this);
}